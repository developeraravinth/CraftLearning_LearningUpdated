package businesscomponents;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.sql.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;

import commonComponents.com.cognizant.framework.Status;
import com.google.common.base.Function;

import commonComponents.supportlibraries.ScriptHelper;
import uimap.MyWellmark_OR;

public class MyWellmark extends MyWellmark_CommonFunctions  {
	
	public MyWellmark(ScriptHelper scriptHelper) {
			super(scriptHelper);		
	}
	public void options_displayed_under_Sort_dropdown_in_Claim_listpage(){
		if (driver.isElementvisible(MyWellmark_OR.myWellmark)) {
			performAction(MyWellmark_OR.myWellmark, "SCROLLANDCLICK","" );
		}
		
		performAction(MyWellmark_OR.claimsLink, "SCROLLANDCLICK","" );
		
		driverUtil.waitFor(2000);
		//performAction(MyWellmark_OR.claimsLink, "SCROLLANDCLICK","" );
		validateSortingByStatus();
		validateSortingByDate("NewestToOld");
		validateSortingByDate("OldToNewest");
		validateSortingByYouPay("LowToHigh");
		validateSortingByYouPay("HighToLow");
		
	}
	public void options_displayed_under_Status_dropdown_in_Claim_listpage() throws InterruptedException{
		if (driver.isElementvisible(MyWellmark_OR.myWellmark)) {
		performAction(MyWellmark_OR.myWellmark, "SCROLLANDCLICK","" );
		}
		Thread.sleep(2000);
		performAction(MyWellmark_OR.claimsLink, "SCROLLANDCLICK","" );
		//performAction(MyWellmark_OR.claimsLink, "SCROLLANDCLICK","" );
		Thread.sleep(2000);
		List<WebElement> statusList = driver.findElements(MyWellmark_OR.statusOption);
		Thread.sleep(2000);
		for (WebElement webElement : statusList) {
			String status = webElement.getText().trim();
			if(status.equalsIgnoreCase("All")){
				validateStatusAllFilter();
			}
			else if(status.equalsIgnoreCase("Paid")){
				validateStatusFilter("Paid");
			}
			else if(status.equalsIgnoreCase("Pending")){
				validateStatusFilter("Pending");
			}
			else if(status.equalsIgnoreCase("Denied")){
				validateStatusFilter("Denied");
			}
		}
	}
	public void claim_list_details_for_Tier1_members(){
		if (driver.isElementVisible(MyWellmark_OR.myWellmark)) {
			performAction(MyWellmark_OR.myWellmark, "SCROLLANDCLICK","" );	
		}
		
/*		//Integrating with Fluent wait here
		FluentWait<WebDriver> fluwait = new FluentWait<WebDriver>((WebDriver) driver)
				.withTimeout(30, TimeUnit.SECONDS)
				.pollingEvery(5, TimeUnit.SECONDS)
				.ignoring(NoSuchElementException.class);
		
		WebElement element = fluwait.until(new Function<WebDriver, WebElement>() {

			@Override
			public WebElement apply(WebDriver driver) {
				WebElement element = driver.findElement(By.xpath("(//div[@class[contains(.,'latest-claims-container')]]//following-sibling::*)[1]"));
				if (driver.) {
					
				}
				return null;
			}
			
		});*/
		
		driver.manage().timeouts().implicitlyWait(10000, TimeUnit.SECONDS);
		
		performAction(MyWellmark_OR.claimsLink, "SCROLLANDCLICK","" );
		driverUtil.waitFor(2000);
		selectValueFromDropdownForGivenId(MyWellmark_OR.statusDrp,2) ;
		driverUtil.waitFor(2000);
		List<WebElement> paidClaims = driver.findElements(MyWellmark_OR.claims);
		for (WebElement webElement : paidClaims) {
			String date = webElement.findElement(MyWellmark_OR.paidDate).getText();
			if (!date.equals(null)) {
				report.updateTestLog("Paid - Service Date", "Service Date is displayed", Status.PASS);
			} else {
				report.updateTestLog("Paid - Service Date", "Service Date not displayed", Status.FAIL);
			}
			String patientName = webElement.findElement(MyWellmark_OR.patientName).getText();
			if (!patientName.equals(null)) {
				report.updateTestLog("Paid - Patient Name", "Patient Name is displayed", Status.PASS);
			} else {
				report.updateTestLog("Paid - Patient Name", "Patient Name not displayed", Status.FAIL);
			}
			String youPay = webElement.findElement(MyWellmark_OR.youPay).getText();
			if (!youPay.equals(null)) {
				report.updateTestLog("Paid - You Pay", "You Pay is displayed", Status.PASS);
			} else {
				report.updateTestLog("Paid - You Pay", "You Pay not displayed", Status.FAIL);
			}
			String status = webElement.findElement(MyWellmark_OR.status).getText();
			if (!status.equals(null)) {
				report.updateTestLog("Paid - Claim Status", "Claim Status is displayed", Status.PASS);
			} else {
				report.updateTestLog("Paid - Claim Status", "Claim Status not displayed", Status.FAIL);
			}
		}
		selectValueFromDropdownForGivenId(MyWellmark_OR.statusDrp,1) ;
		driverUtil.waitFor(2000);
		List<WebElement> pendingClaims = driver.findElements(MyWellmark_OR.claims);
		for (WebElement webElement : pendingClaims) {
			String date = webElement.findElement(MyWellmark_OR.paidDate).getText();
			if (!date.equals(null)) {
				report.updateTestLog("Paid - Service Date", "Service Date is displayed", Status.PASS);
			} else {
				report.updateTestLog("Paid - Service Date", "Service Date not displayed", Status.FAIL);
			}
			String patientName = webElement.findElement(MyWellmark_OR.patientName).getText();
			if (!patientName.equals(null)) {
				report.updateTestLog("Paid - Patient Name", "Patient Name is displayed", Status.PASS);
			} else {
				report.updateTestLog("Paid - Patient Name", "Patient Name not displayed", Status.FAIL);
			}
			/*String youPay = webElement.findElement(MyWellmark_OR.youPay).getText();
			if (!youPay.equals(null)) {
				report.updateTestLog("Paid - You Pay", "You Pay is displayed", Status.FAIL);
			} else {
				report.updateTestLog("Paid - You Pay", "You Pay not displayed", Status.PASS);
			}*/
			String status = webElement.findElement(MyWellmark_OR.status).getText();
			if (!status.equals(null)) {
				report.updateTestLog("Paid - Claim Status", "Claim Status is displayed", Status.PASS);
			} else {
				report.updateTestLog("Paid - Claim Status", "Claim Status not displayed", Status.FAIL);
			}
		}
	}
	public void message_displayed_in_model_window_for_the__denied_claim(){
		performAction(MyWellmark_OR.claimsLink, "SCROLLANDCLICK","" );
		driverUtil.waitFor(2000);
		selectValueFromDropdownForGivenTextContains(MyWellmark_OR.statusDrp,"Denied");
		driverUtil.waitFor(1000);
		performAction(MyWellmark_OR.deniedClaim, "SCROLLANDCLICK","" );
		if(driver.isElementVisible(MyWellmark_OR.deniedClaimReason, 150)!=false) {
			report.updateTestLog("Denied Claim", "Denied Claim Reason is displyed successfully", Status.PASS);
		}
		else{
			report.updateTestLog("Denied Claim", "Denied Claim Reason is not displyed successfully", Status.FAIL);
		}
	}
	public void claim_line_details_displayed_in_claim_details_page_MyWellmark(){
		performAction(MyWellmark_OR.claimsLink, "SCROLLANDCLICK","" );
		performAction(MyWellmark_OR.claimDetailsLink, "SCROLLANDCLICK","" );
		performAction(MyWellmark_OR.expandCostDetails, "SCROLLANDCLICK","" );
		String number = driver.findElement(MyWellmark_OR.claimNumber).getText();
		String claimNumber = number.substring(6);
		String amountBilled = driver.findElement(MyWellmark_OR.amountBilled).getText();
		String wellmarkDiscount = driver.findElement(MyWellmark_OR.wellmarkDiscount).getText();
	    String wellmarkPaid = driver.findElement(MyWellmark_OR.wellmarkPaid).getText();
	    String youPayClaim = driver.findElement(MyWellmark_OR.youPayClaim).getText();
	    String deductible = driver.findElement(MyWellmark_OR.deductible).getText();
	    String Copay = driver.findElement(MyWellmark_OR.Copay).getText();
	    String Coinsurance = driver.findElement(MyWellmark_OR.Coinsurance).getText();
	    String AmountNotCovered = driver.findElement(MyWellmark_OR.AmountNotCovered).getText();
	    PrintWriter writer = null;
		try {
			writer = new PrintWriter("C:\\ClaimNumber.txt", "UTF-8");
		} catch (FileNotFoundException | UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    writer.println(claimNumber);
	    writer.println(amountBilled.replace("$", ""));
	    writer.println(wellmarkDiscount.replace("$", ""));
	    writer.println(wellmarkPaid.replace("$", ""));
	    writer.println(youPayClaim.replace("$", ""));
	    writer.println(deductible.replace("$", ""));
	    writer.println(Copay.replace("$", ""));
	    writer.println(Coinsurance.replace("$", ""));
	    writer.println(AmountNotCovered.replace("$", ""));
	    writer.close();
	}
	public void claim_line_details_displayed_in_claim_details_page_CSI() throws ClassNotFoundException, SQLException, InterruptedException{
		String line = null;
	    FileReader fileReader;
	    ArrayList<String> claimDetailsArr = new ArrayList<String>();
		try {
			fileReader = new FileReader("C:\\ClaimNumber.txt");
			BufferedReader bufferedReader = 
	                new BufferedReader(fileReader);
			//claimNumber = bufferedReader.readLine();
			while((line = bufferedReader.readLine()) != null) {
				claimDetailsArr.add(line);
            }  
			 bufferedReader.close(); 
		} catch (IOException e) {
			e.printStackTrace();
		}
		String subscriberId = null;
		String query = "Select A.CLCL_ID,C.SBSB_ID from CMC_CLCL_CLAIM as A join CMC_MEME_MEMBER as B on A.MEME_CK=B.MEME_CK join CMC_SBSB_SUBSC as C on B.SBSB_CK=C.SBSB_CK where A.CLCL_ID='"+claimDetailsArr.get(0)+"'";
		ResultSet rs = executeQuery(query);
		try {
			while(rs.next()) {
				subscriberId = rs.getString("SBSB_ID").trim();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		performAction(MyWellmark_OR.memberId_CSI, "sendkeys",subscriberId );
		performAction(MyWellmark_OR.claimNumber_CSI, "sendkeys",claimDetailsArr.get(0) );
		performAction(MyWellmark_OR.buttonSearch_CSI, "SCROLLANDCLICK","" );
		Thread.sleep(2000);
		performAction(MyWellmark_OR.claimLink_CSI, "SCROLLANDCLICK","" );
		
		String amountCharged = driver.findElement(By.xpath("//table[@id='ContentPlaceHolder1_tblSummaryAmount']/tbody/tr[2]/td[2]")).getText();
		String amountPaid = driver.findElement(By.xpath("//table[@id='ContentPlaceHolder1_tblSummaryAmount']/tbody/tr[4]/td[2]")).getText();
		String deductible = driver.findElement(By.xpath("//table[@id='ContentPlaceHolder1_tblSummaryAmount']/tbody/tr[5]/td[2]")).getText();
		String coPayment = driver.findElement(By.xpath("//table[@id='ContentPlaceHolder1_tblSummaryAmount']/tbody/tr[6]/td[2]")).getText();
		String coInsurance = driver.findElement(By.xpath("//table[@id='ContentPlaceHolder1_tblSummaryAmount']/tbody/tr[7]/td[2]")).getText();
		String memberResponsibility = driver.findElement(By.xpath("//table[@id='ContentPlaceHolder1_tblSummaryAmount']/tbody/tr[8]/td[2]")).getText();
		String networkSavings = driver.findElement(By.xpath("//table[@id='ContentPlaceHolder1_tblSummaryAmount']/tbody/tr[9]/td[2]")).getText();
		if(amountCharged.equals(claimDetailsArr.get(1)) && networkSavings.equals(claimDetailsArr.get(2)) 
				&& amountPaid.equals(claimDetailsArr.get(3)) && memberResponsibility.equals(claimDetailsArr.get(4)) 
				&& deductible.equals(claimDetailsArr.get(5)) && coPayment.equals(claimDetailsArr.get(6))
				&& coInsurance.equals(claimDetailsArr.get(7))){
			report.updateTestLog("Claim Details CSI", "Claim Details are matched with CSI", Status.PASS);
		}
		else{
			report.updateTestLog("Claim Details CSI", "Claim Details are not matched with CSI", Status.FAIL);
		}
	}
	public void order_Dental_ID_Card_PPO() throws ClassNotFoundException, SQLException{
		//String subsId = findSubscriber();
		String subsId = "W00075544";
		extractdata(subsId);
		selectType();
		registerMember();
		registerMemberStep2();
		performAction(MyWellmark_OR.myPlansLink, "SCROLLANDCLICK","" );
		performAction(MyWellmark_OR.viewIdCard, "SCROLLANDCLICK","" );
		if(driver.isElementVisible(MyWellmark_OR.dentalCard, 150)!=false &&  driver.isElementVisible(MyWellmark_OR.dental_IdCardFrontSide, 150)!=false && driver.isElementVisible(MyWellmark_OR.dental_IdCardBackSide, 150)!=false) {
			report.updateTestLog("View Id Card", "Id Card Front and Back are displayed", Status.PASS);
		}
		else{
			report.updateTestLog("View Id Card", "Id Card Front and Back are not displayed", Status.FAIL);
		}
		if(driver.isElementVisible(MyWellmark_OR.dentalOrderButton, 150)==false) {
			report.updateTestLog("Order Button", "Order Button are not displayed", Status.PASS);
		}
		else{
			report.updateTestLog("Order Button", "Order Button are displayed", Status.FAIL);
		}
		//performAction(MyWellmark_OR.orderButton, "SCROLLANDCLICK","" );
	}
	public void order_Medical_ID_Card_Future_effective_member() throws ClassNotFoundException, SQLException{
		//String subsId = findSubscriber();
		String subsId = "WS0212747"; //183AD4563SPOUSE00INT

		extractdata(subsId);
		selectType();
		registerMember();
		registerMemberStep2();
		performAction(MyWellmark_OR.myPlansLink, "SCROLLANDCLICK","" );
		performAction(MyWellmark_OR.viewIdCard, "SCROLLANDCLICK","" );
		if(driver.isElementVisible(MyWellmark_OR.medicalCard, 150)!=false &&  driver.isElementVisible(MyWellmark_OR.dental_IdCardFrontSide, 150)!=false && driver.isElementVisible(MyWellmark_OR.dental_IdCardBackSide, 150)!=false) {
			report.updateTestLog("View Id Card", "Id Card Front and Back are displayed", Status.PASS);
		}
		else{
			report.updateTestLog("View Id Card", "Id Card Front and Back are not displayed", Status.FAIL);
		}
		if(driver.isElementVisible(MyWellmark_OR.medicalOrderButton, 150)==false) {
			report.updateTestLog("Order Button", "Order Button are not displayed", Status.PASS);
		}
		else{
			report.updateTestLog("Order Button", "Order Button are displayed", Status.FAIL);
		}
		//performAction(MyWellmark_OR.orderButton, "SCROLLANDCLICK","" );
	}
	public void medical_ID_card_for_Cancelled_Member() throws ClassNotFoundException, SQLException{
		String subsId = findSubscriber();
		extractdata(subsId);
		selectType();
		registerMember();
		registerMemberStep2();
		performAction(MyWellmark_OR.myPlansLink, "SCROLLANDCLICK","" );
		//performAction(MyWellmark_OR.viewIdCard, "SCROLLANDCLICK","" );
		if(driver.isElementVisible(MyWellmark_OR.viewIdCard, 150)==false) {
			report.updateTestLog("View Id Card", "View Id Card are not displayed", Status.PASS);
		}
		else{
			report.updateTestLog("View Id Card", "View Id Card are displayed", Status.FAIL);
		}
	}
	public void dental_ID_card_Layout_for_IA_PPO_Plan() throws ClassNotFoundException, SQLException{
		//String subsId = findSubscriber();
		String subsId = "W00431604";
		extractdata(subsId);
		selectType();
		registerMember();
		registerMemberStep2();
		enterCredentials();
		performAction(MyWellmark_OR.myPlansLink, "SCROLLANDCLICK","" );
		driver.waitTillPageLoaded();
		driver.waitTillPageLoaded();
		performAction(MyWellmark_OR.viewIdCard, "SCROLLANDCLICK","" );
		if(driver.isElementVisible(MyWellmark_OR.dentalCard, 150)!=false &&  driver.isElementVisible(MyWellmark_OR.dental_IdCardFrontSide, 150)!=false && driver.isElementVisible(MyWellmark_OR.dental_IdCardBackSide, 150)!=false) {
			report.updateTestLog("View Id Card", "Id Card Front and Back are displayed", Status.PASS);
		}
		else{
			report.updateTestLog("View Id Card", "Id Card Front and Back are not displayed", Status.FAIL);
		}
		dentalIdCard_FrontSideValidation();
		dentalIdCard_BackSideValidation();
		invokeEVBI();
		validateEVBI_MemberDetails();
	}
	public void medical_ID_card_Layout_for_Value_Health() throws ClassNotFoundException, SQLException{
		//String subsId = findSubscriber();
		String subsId = "W00431604";
		extractdata(subsId);
		selectType();
		registerMember();
		registerMemberStep2();
		enterCredentials();
		performAction(MyWellmark_OR.myPlansLink, "SCROLLANDCLICK","" );
		driver.waitTillPageLoaded();
		driver.waitTillPageLoaded();
		performAction(MyWellmark_OR.viewIdCard, "SCROLLANDCLICK","" );
		if(driver.isElementVisible(MyWellmark_OR.medicalCard, 150)!=false &&  driver.isElementVisible(MyWellmark_OR.dental_IdCardFrontSide, 150)!=false && driver.isElementVisible(MyWellmark_OR.dental_IdCardBackSide, 150)!=false) {
			report.updateTestLog("View Id Card", "Id Card Front and Back are displayed", Status.PASS);
		}
		else{
			report.updateTestLog("View Id Card", "Id Card Front and Back are not displayed", Status.FAIL);
		}
		
	}
	public void search_for_a_Provider_Widget_for_member_with_dental_only_plan(){
		checkMyplanLink();
		validateDentistIcon();
		validateDentistUrl();
	}
	public void search_for_a_Provider_Widget_for_member_with_all_benefits(){
		checkMyplanLink();
		validateDoctorIcon();
		validateDoctorUrl();
		validateFaciltyIcon();
		validateFaciltyUrl();
		validatePharmacyIcon();
		validatePharmacyUrl();
		validateDentistIcon();
		validateDentistUrl();
	}
	public void claim_list_details_for_Tier_2_members(){
		checkClaimLink();
		checkClaimDetails();		
	}
	public void homepage_Hyvee_narrow_network() throws ClassNotFoundException, SQLException{
		String subsId = findSubscriber();
		extractdata(subsId);
		selectType();
		registerMember();
		registerMemberStep2();
		checkHighPerformanceLink();
	}
	public void homepage_Future_Effective_Policy() throws ClassNotFoundException, SQLException{
		String subsId = findSubscriber();
		extractdata(subsId);
		selectType();
		registerMember();
		registerMemberStep2();
		validateFutureEffMsg();
	}
	public void homepage_UIGradCare_link() throws ClassNotFoundException, SQLException{
		/*extractdata();
		selectType();
		registerMember();*/
		CheckUiGradeCare();
	}
	/*****Praveen******/
	 public void change_username()
	 {
		 String userName = dataTable.getData("General_Data", "Username");
		 String s1=RandomStringUtils.randomAlphanumeric(3);
		 String newuser=userName.concat(s1.toUpperCase());
		 dataTable.putData("General_Data", "Username", newuser);
		 Changetheusername();
		 logoutmywellmark();		 
		 invokeApplication();
		 enterCredentials();		 
		 dataTable.putData("General_Data", "Username", userName);
		 Changetheusername(); 
		}
	 public void error_message_for_invalid_username()
	 {
		 Error_message_for_invalid();		 
	 }
	 public void change_security_question()
	 {
		 change_security_ques();
		 	 
	 }
	 public void error_message_for_invalid_securityques()
	 {
		 Error_message_securityques();
	 }
	 public void change_password()
	 {
		 String oldpassword = dataTable.getData("General_Data", "Password");
		 String s1=RandomStringUtils.randomAlphanumeric(8);
		 //String newpwd=s1.toUpperCase();
		 String newpwd = dataTable.getData("General_Data", "Password") + "007";
		 dataTable.putData("General_Data", "newpassword", newpwd);
		 Changethepassword();
		 logoutmywellmark();		 
		 invokeApplication();
		 enterCredentials();		 
		 dataTable.putData("General_Data", "newpassword", oldpassword);
		 Changethepassword(); 
		}
	 public void error_message_for_invalidpwd()
	 {
		 error_message_invalidpwd(); 
	 }
	 public void medical_idcard_validation()
	 {
		 idcardvalidationcheckallmembers();
		 idcardfrontlayout();
		 idcardbacklayout();
		 driver.manage().deleteAllCookies();
		 invokeEVBI();
		 validateEVBI_MemberDetails();		 
	 }
	 public void medical_idcard_validation_synergy()
	 {
		 idcardvalidationcheckallmembers();
		 idcardfrontlayout_synergy();
		 idcardbacklayout();
		 driver.manage().deleteAllCookies();
		 invokeEVBI();
		 validateEVBI_MemberDetails();		 
	 }

	
	
}