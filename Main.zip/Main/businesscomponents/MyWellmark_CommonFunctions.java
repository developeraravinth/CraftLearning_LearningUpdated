package businesscomponents;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import commonComponents.com.cognizant.framework.Status;
import commonComponents.com.cognizant.framework.selenium.UtilityFunctions;
import commonComponents.supportlibraries.ScriptHelper;
import uimap.MyWellmark_OR;


public class MyWellmark_CommonFunctions extends UtilityFunctions {
String parentWindowHandler1;
public static String bMedProdSlcted = null;
public static String brxProdSlcted  = null;
public static String bDenProdSlcted  = null;
public static String bHCMProdSlcted  = null;
public static String carrierID  = null;
public static String PCPSlcted  = null;
String sbsbid=null;
String ssn= null;String dob= null;String lastname = null;String firstname= null;String zipcode = null;String phone=null;
int intTotalQuotes_retire=0;
int intTotalQuotes=0;
/**
 * Constructor to initialize the component library
 * @param scriptHelper The {@link ScriptHelper} object passed from the {@link DriverScript}
 */
public MyWellmark_CommonFunctions(ScriptHelper scriptHelper) {
	super(scriptHelper);
	
}
//Invoke Application
public void invokeApplication(){
	String ApplicationURL=dataTable.getData("General_Data", "ApplicationURL_Test");
	String LoginPageTitle=dataTable.getData("General_Data", "LoginPage"); //As of now changed the loginpage name
	driver.get(ApplicationURL);
	driverUtil.waitFor(4000);
	//verifies with page title
	String PageTitleLoaded = driver.getTitle();
	if (PageTitleLoaded.equals(LoginPageTitle)) {
		report.updateTestLog("Invoke Application", "Invoke Application Successful", Status.PASS);
	} 
	else {
		report.updateTestLog("Invoke Application", "Invoke Application Unsuccessful", Status.FAIL);
	}
}
public void selectValueFromDropdownForGivenTextContains(By by,String textToBeSelected){
	Select dropDownList = new Select(driver.findElement(by));
	boolean flag=false;
	List<WebElement> options = dropDownList.getOptions();
	for(WebElement option:options){
		if((option.getText().trim()).contains(textToBeSelected)){
			dropDownList.selectByVisibleText(option.getText().trim());
			flag=true;
			break;
		}
	}
	if(flag){
		report.updateTestLog("select Value From Dropdown For Given Text", "'"+textToBeSelected+"' is selected", Status.DONE);
	}else{
		report.updateTestLog("select Value From Dropdown For Given Text", "'"+textToBeSelected+"' is not selected", Status.FAIL);
	}
}
// Logout Application
public void logOutApplication(){
	//performAction(MyWellmark_OR.btnProfile, "CLICK","" );
	//performAction(MyWellmark_OR.btnLogout, "CLICK","" );
}	
//Enter Credentials 
public void enterCredentials(){		
	String userName=dataTable.getData("General_Data", "Username");
	String passWord=dataTable.getData("General_Data", "Password");
	//Login to Application
	driver.findElement(MyWellmark_OR.txtUsername).sendKeys(userName);
	driver.findElement(MyWellmark_OR.txtPassword).sendKeys(passWord);
	if (!driver.findElement(By.xpath("//button[contains(.,'Login')]")).isDisplayed()) {
		performAction(MyWellmark_OR.btnLogin, "SCROLLANDCLICK","" );	
	}else{
		performAction(By.xpath("//button[contains(.,'Login')]"), "CLICK", "");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}
		
	//Commented below threads as of now
	/*if(driver.isElementVisible(MyWellmark_OR.wellmarkassessment))
	{
		performAction(MyWellmark_OR.continuetomywellmark,"CLICK","");
	}*/
	if (driver.isElementVisible(MyWellmark_OR.welcome)) {
		report.updateTestLog("Login Application", "Login Successful", Status.PASS);
	} else {
		report.updateTestLog("Login Application", "Login not Successful", Status.FAIL);
	}
}

public void selectMember(){
	String memberSSN = dataTable.getData("General_Data", "SSN/SID");
	List<WebElement> searchResults = driver.findElements(By.xpath("//table/tbody/tr"));
	for (int i = 1; i <=searchResults.size(); i++) {
		String relation = driver.findElement(By.xpath("//table/tbody/tr["+i+"]/td[5]")).getText();
		String ssn = driver.findElement(By.xpath("//table/tbody/tr["+i+"]/td[6]")).getText();
		String status = driver.findElement(By.xpath("//table/tbody/tr["+i+"]/td[7]")).getText();
		if (ssn.trim().equals(memberSSN.trim()) && status.trim().equals("Active") && relation.trim().equals("Policyholder")) {
			performAction(By.xpath("//table/tbody/tr["+i+"]/td[1]/a"), "SCROLLANDCLICK","");
			break;
		} else {
			report.updateTestLog("Select Member", "No Member Found", Status.FAIL);	
		}
	}
}
	public void validateStatusFilter(String status){
		List<WebElement> claims = null;
		String claimStatus = null;
		selectValueFromDropdownForGivenTextContains(MyWellmark_OR.statusDrp,status);
		if (status.equals("Denied")) {
			claims = driver.findElements(By.xpath("//div[@role='region']//p/child::span[contains(.,'Denied')]"));
		} else {
			claims = driver.findElements(MyWellmark_OR.claims);
		}
		
		int paid =0,pending=0,denied=0;
		
		for (WebElement claim : claims) {
			if (status.equals("Denied")) {
				claimStatus = driver.findElement(By.xpath("(//div[@role='region']//p/child::span[contains(.,'Denied')]//a/span)[1]")).getText().trim();
			} else {
				claimStatus = claim.findElement(MyWellmark_OR.claimStatus).getText().trim();
			}
			
			
			if(claimStatus.contains("PAID")){
				paid =paid +1;
			}
			else if(claimStatus.equalsIgnoreCase("Pending")){
				pending = pending + 1;
			}
			else if(claimStatus.equalsIgnoreCase("Denied")){
				denied = denied + 1;
			}
		}
			if (status.equalsIgnoreCase("Paid")&& paid>0 && claims.size()==paid ) {
				report.updateTestLog("Claim list", "Paid Status Claims  are displayed", Status.PASS);
			} 
			else if (status.equalsIgnoreCase("Pending")&& pending>0 && claims.size()==pending ) {
				report.updateTestLog("Claim list", "Pending Status Claims  are displayed", Status.PASS);
			}
			else if (status.equalsIgnoreCase("Denied")&& denied>0 && claims.size()==denied ) {
				report.updateTestLog("Claim list", "Denied Status Claims  are displayed", Status.PASS);
			}
			else {
				report.updateTestLog("Claim list", "Claims Status are not displayed properly", Status.FAIL);
			}
		
	}
	public void validateStatusAllFilter(){
		List<WebElement> statusList = driver.findElements(MyWellmark_OR.statusOption);
		selectValueFromDropdownForGivenTextContains(MyWellmark_OR.statusDrp,"All");
		//List<WebElement> claims = driver.findElements(MyWellmark_OR.claims);
		List<WebElement> claims = driver.findElements(By.xpath("//div[@class='claims-list ng-star-inserted']//p[@class='ng-star-inserted']/span[3]"));
		int paid =0,pending=0,denied=0;
		for (WebElement claim : claims) {
			String claimStatus = claim.getText();
			if(claimStatus.equalsIgnoreCase("Paid")){
				paid =paid +1;
			}
			else if(claimStatus.equalsIgnoreCase("Pending")){
				pending = pending + 1;
			}
			else if(claimStatus.equalsIgnoreCase("Denied")){
				denied = denied + 1;
			}
		}
		if (claims.size()>0 ) {
			report.updateTestLog("Claim list", "All Status Claims  are displayed", Status.PASS);
		} 
		else {
			report.updateTestLog("Claim list", "All Status Claims  are not displayed", Status.FAIL);
		}
	}
	public void validateSortingByStatus(){
		ArrayList<String> statusClaims_actual = new ArrayList<String>();
		ArrayList<String> statusClaims_sorted = new ArrayList<String>();
		selectValueFromDropdownForGivenId(MyWellmark_OR.sortDrp,0) ;
		List<WebElement> claims = driver.findElements(By.xpath("//div[@class='claims-list ng-star-inserted']//p[@class='ng-star-inserted']/span[3]"));
		for (WebElement claim : claims) {
			String claimStatus = claim.getText();
			statusClaims_actual.add(claimStatus);
			statusClaims_sorted.add(claimStatus);
		}
		Collections.sort(statusClaims_sorted);
		Collections.reverse(statusClaims_sorted);
		System.out.println(statusClaims_sorted);
		System.out.println(statusClaims_actual);
		if(statusClaims_actual.equals(statusClaims_sorted)){
			report.updateTestLog("Status Sorted", "Claims sorted by status", Status.PASS);
		}
		else{
			report.updateTestLog("Status Sorted", "Claims not sorted by status", Status.FAIL);
		}
	}
	public void validateSortingByDate(String range){
		ArrayList<Date> claims_actual = new ArrayList<Date>();
		ArrayList<Date> claims_sorted = new ArrayList<Date>();
		if(range.equals("NewestToOld")){
			selectValueFromDropdownForGivenId(MyWellmark_OR.sortDrp,1) ;
		}
		else if(range.equals("OldToNewest")){
			selectValueFromDropdownForGivenId(MyWellmark_OR.sortDrp,2) ;
		}
		List<WebElement> claims = driver.findElements(By.xpath("//div[@class='claims-list ng-star-inserted']//p[@class='field-label ng-star-inserted']"));
		for (WebElement claim : claims) {
			String dateText = claim.getText();
			Date date = null;
			try {
				date = new SimpleDateFormat("MMM d,yyyy").parse(dateText);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			claims_actual.add(date);
			claims_sorted.add(date);
		}
		
		Collections.sort(claims_sorted);
		if(range.equals("NewestToOld")){
		Collections.reverse(claims_sorted);
		}
		System.out.println(claims_sorted);
		System.out.println(claims_actual);
		if(claims_actual.equals(claims_sorted)){
			report.updateTestLog("Status Sorted", "Claims sorted by "+range, Status.PASS);
		}
		else{
			report.updateTestLog("Status Sorted", "Claims not sorted by "+range, Status.FAIL);
		}
	}
	public void validateSortingByYouPay(String range){
		ArrayList<Double> claims_actual = new ArrayList<Double>();
		ArrayList<Double> claims_sorted = new ArrayList<Double>();
		if(range.equals("LowToHigh")){
		selectValueFromDropdownForGivenId(MyWellmark_OR.sortDrp,3) ;
		}
		else if(range.equals("HighToLow")){
			selectValueFromDropdownForGivenId(MyWellmark_OR.sortDrp,4) ;
		}
		//List<WebElement> claims = driver.findElements(By.xpath("//div[@class='claims-list ng-star-inserted']//p[@class='ng-star-inserted']/span[3]"));
		List<WebElement> claims = driver.findElements(By.xpath("//span[contains(text(),'You Pay:')]/parent::p"));
		
		for (WebElement claim : claims) {
			String amountText = claim.getText();
			Double amount = null;
			//if(statusText.equalsIgnoreCase("Paid")){
				String[] amountArr= amountText.split(":");
				amount = Double.valueOf(amountArr[1].replace("$", ""));
				claims_actual.add(amount);
				claims_sorted.add(amount);
			//}
		}
		
		Collections.sort(claims_sorted);
		if(range.equals("HighToLow")){
		Collections.reverse(claims_sorted);
		}
		System.out.println(claims_sorted);
		System.out.println(claims_actual);
		if(claims_actual.equals(claims_sorted)){
			report.updateTestLog("Status Sorted", "Claims sorted by "+range, Status.PASS);
		}
		else{
			report.updateTestLog("Status Sorted", "Claims not sorted by "+range, Status.FAIL);
		}
	}
	public void checkMyplanLink(){
		int size= driver.findElements(MyWellmark_OR.myplanlink).size();
		if(size==1){
			performAction(MyWellmark_OR.myplanlink, "SCROLLANDCLICK", "");
			driver.waitTillPageLoaded();
			driver.navigate().back();
			driver.waitTillPageLoaded();
		}
	}
	public void validateDentistIcon(){
		ArrayList<String> tabs1 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs1.get(0)); 
		int imagestate = driver.findElements(By.xpath("//img[@src='assets/img/icons/toothbrush-and-cup.png']")).size();
		if (imagestate==1) {
			performAction(MyWellmark_OR.dentistlink, "SCROLLANDCLICK", "");
			report.updateTestLog("find a dentist icon ", "system displayed dentist icon and clicked succesfully", Status.PASS);
		}
		else
		{
			report.updateTestLog("find a dentist icon ", "system not displayed dentist icon and not clicked succesfully", Status.FAIL);
		}
	}
	public void validateDoctorIcon(){
		int imagestate = driver.findElements(By.xpath("//img[@src='assets/img/icons/doctor.png']")).size();
		if (imagestate==1) {
			performAction(MyWellmark_OR.doctorlink, "SCROLLANDCLICK", "");
			report.updateTestLog("find a Doctor icon ", "system displayed Doctor icon and clicked succesfully", Status.PASS);
		}
		else
		{
			report.updateTestLog("find a Doctor icon ", "system not displayed Doctor icon and not clicked succesfully", Status.FAIL);
		}
	}
	public void validateFaciltyIcon(){
		ArrayList<String> tabs1 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs1.get(0)); 
		int imagestate = driver.findElements(By.xpath("//img[@src='assets/img/icons/facility.png']")).size();
		if (imagestate==1) {
			performAction(MyWellmark_OR.fcailitylink, "SCROLLANDCLICK", "");
			report.updateTestLog("find a Facility icon ", "system displayed Facility icon and clicked succesfully", Status.PASS);
		}
		else
		{
			report.updateTestLog("find a Facility icon ", "system not displayed Facility icon and not clicked succesfully", Status.FAIL);
		}
	}
	public void validatePharmacyIcon(){
		ArrayList<String> tabs1 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs1.get(0)); 
		int imagestate = driver.findElements(By.xpath("//img[@src='assets/img/icons/prescription.png']")).size();
		if (imagestate==1) {
			performAction(MyWellmark_OR.pharmacylink, "SCROLLANDCLICK", "");
			report.updateTestLog("find a Pharmacy icon ", "system displayed Pharmacy icon and clicked succesfully", Status.PASS);
		}
		else
		{
			report.updateTestLog("find a Pharmacy icon ", "system not displayed Pharmacy icon and not clicked succesfully", Status.FAIL);
		}
	}
	public void validateDoctorUrl(){
		/*String childWindowHandler2 = driver.getWindowHandle();
		driver.switchTo().window(childWindowHandler2);
		driver.switchTo().activeElement();*/
		String paragraph = dataTable.getData("General_Data", "Paragraph");
		String doctorparagraph = driver.findElement(By.xpath("//div[@aria-hidden='false']//div[@class='modal-body']//p")).getText();
		int continuebtn = driver.findElements(By.xpath("//div[@aria-hidden='false']//div[@class='modal-body']//a[contains(.,'Continue')]")).size();
		int cancelbtn = driver.findElements(By.xpath("//div[@aria-hidden='false']//div[@class='modal-body']//a[contains(.,'Cancel')]")).size();
		if(paragraph.contains(doctorparagraph)&&(continuebtn==1)&&(cancelbtn==1)){
			report.updateTestLog("Interstitial message", "Interstitial message must be displayed with Continue and Cancel button", Status.PASS);
		}
		performAction(MyWellmark_OR.doctorcontinuebtn, "SCROLLANDCLICK", "");
		driver.waitTillPageLoaded();
		driverUtil.waitFor(10000);
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1)); 
		String currenturl = driver.getCurrentUrl();
		String DoctorUrl = dataTable.getData("General_Data", "DoctorUrl");
		if(DoctorUrl.contains(currenturl)){
			report.updateTestLog("DoctorUrl", "current Url matched with given Doctor url succesfully", Status.PASS);
		}else
		{
			report.updateTestLog("DoctorUrl", "current Url not matched with given Doctor url succesfully", Status.FAIL);
		}
	}
	public void validateFaciltyUrl(){
		/*String childWindowHandler2 = driver.getWindowHandle();
		driver.switchTo().window(childWindowHandler2);
		driver.switchTo().activeElement();*/
		String paragraph = dataTable.getData("General_Data", "Paragraph");
		String doctorparagraph = driver.findElement(By.xpath("//div[@aria-hidden='false']//div[@class='modal-body']//p")).getText();
		int continuebtn = driver.findElements(By.xpath("//div[@aria-hidden='false']//div[@class='modal-body']//a[contains(.,'Continue')]")).size();
		int cancelbtn = driver.findElements(By.xpath("//div[@aria-hidden='false']//div[@class='modal-body']//a[contains(.,'Cancel')]")).size();
		if(paragraph.contains(doctorparagraph)&&(continuebtn==1)&&(cancelbtn==1)){
			report.updateTestLog("Interstitial message", "Interstitial message must be displayed with Continue and Cancel button", Status.PASS);
		}
		performAction(MyWellmark_OR.facilitycontinuebtn, "SCROLLANDCLICK", "");
		driver.waitTillPageLoaded();
		driverUtil.waitFor(10000);
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(2)); 
		String currenturl = driver.getCurrentUrl();
		String FaciltyUrl = dataTable.getData("General_Data", "FaciltyUrl");
		if(FaciltyUrl.contains(currenturl)){
			report.updateTestLog("Facilty Url ", "current Url matched with given Facilty url succesfully", Status.PASS);
		}else
		{
			report.updateTestLog("Facilty Url ", "current Url not matched with given Facilty url succesfully", Status.FAIL);
		}
	}
	public void validatePharmacyUrl(){
		/*String childWindowHandler2 = driver.getWindowHandle();
		driver.switchTo().window(childWindowHandler2);
		driver.switchTo().activeElement();*/
		String paragraph = dataTable.getData("General_Data", "Paragraph");
		String doctorparagraph = driver.findElement(By.xpath("//div[@aria-hidden='false']//div[@class='modal-body']//p")).getText();
		int continuebtn = driver.findElements(By.xpath("//div[@aria-hidden='false']//div[@class='modal-body']//a[contains(.,'Continue')]")).size();
		int cancelbtn = driver.findElements(By.xpath("//div[@aria-hidden='false']//div[@class='modal-body']//a[contains(.,'Cancel')]")).size();
		if(paragraph.contains(doctorparagraph)&&(continuebtn==1)&&(cancelbtn==1)){
			report.updateTestLog("Interstitial message", "Interstitial message must be displayed with Continue and Cancel button", Status.PASS);
		}
		performAction(MyWellmark_OR.pharmacycontinuebtn, "SCROLLANDCLICK", "");
		driver.waitTillPageLoaded();
		driverUtil.waitFor(10000);
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(3)); 
		driver.navigate().to("https://sit1www.caremark.com/wps/portal/?screen=ssoLogin");
		String currenturl = driver.getCurrentUrl();
		String PharmacyUrl = dataTable.getData("General_Data", "PharmacyUrl");
		if(PharmacyUrl.contains(currenturl)){
			report.updateTestLog("Pharmacy Url ", "current Url matched with given Pharmacy url succesfully", Status.PASS);
		}else
		{
			report.updateTestLog("Pharmacy Url ", "current Url not matched with given Pharmacy url succesfully", Status.FAIL);
		}
	}
	public void validateDentistUrl(){
		/*String childWindowHandler2 = driver.getWindowHandle();
		driver.switchTo().window(childWindowHandler2);
		driver.switchTo().activeElement();*/
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(4)); 
		driverUtil.waitFor(10000);
		String currenturl = driver.getCurrentUrl();
		String dentalurl = dataTable.getData("General_Data", "DentalUrl");
		if(dentalurl.contains(currenturl)){
			report.updateTestLog("Dentist Url ", "current Url matched with given Dentist url succesfully", Status.PASS);
		}else
		{
			report.updateTestLog("Dentist Url ", "current Url not matched with given Dentist url succesfully", Status.FAIL);
		}
	}
	public void checkClaimLink(){
		int size= driver.findElements(MyWellmark_OR.claimslink).size();
		if(size==1){
			performAction(MyWellmark_OR.claimslink, "SCROLLANDCLICK", "");
			driver.waitTillPageLoaded();
			int state=  driver.findElements(By.xpath("//h1[contains(text(),'Claims')]")).size();
			if(state==1) {
				report.updateTestLog("Claim page ", "System navigated to claim page succesfully", Status.PASS);
			} else {
				report.updateTestLog("Claim page ", "System is not navigated to claim page succesfully", Status.FAIL);
			}
		}
	}
	public void checkClaimDetails(){
		int servicedate= driver.findElements(By.xpath("(//div[@class='claims-list ng-star-inserted'])[1]//p[@class='field-label ng-star-inserted']")).size();
		String patientname = null;String providername=null;String youpay=null;String status= null;
		try {
			patientname = driver.findElement(By.xpath("(((//div[@class='claims-list ng-star-inserted'])[1]//p)[2])")).getText();
			providername= driver.findElement(By.xpath("((//div[@class='claims-list ng-star-inserted'])[1]//p)[3]")).getText();
			//youpay= driver.findElement(By.xpath("((//div[@class='claims-list ng-star-inserted'])[1]//p)[4]")).getText();
			status= driver.findElement(By.xpath("((//div[@class='claims-list ng-star-inserted'])[1]//p)[4]")).getText();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String [] patientnamelist= patientname.split(":");
		String [] providernamelist= providername.split(":");
		//String [] youpaylist= youpay.split(":");
		String [] statuslist= status.split(":");
		//&&(youpaylist[1]!=null)
		//youpay:"+youpaylist[1]+", 
		if ((servicedate==1)&&(patientnamelist[1]!=null)&&(providernamelist[1]!=null)&&(statuslist[1]!=null)) {
			report.updateTestLog("Claim details ", "System displayed Claim details with patientname:"+patientnamelist[1]+", providername:"+providernamelist[1]+", status:"+statuslist[1]+" succesfully", Status.PASS);
		} else {
			report.updateTestLog("Claim details ", "System is not displayed Claim details with patientname:"+patientnamelist[1]+", providername:"+providernamelist[1]+", status:"+statuslist[1]+" succesfully", Status.FAIL);
		}
	}
	public void selectType(){
		/*if (driver.isElementVisible(MyWellmark_OR.usertype)) {
			selectValueFromDropdownForGivenId(MyWellmark_OR.usertype,1) ;	
		}*/
		performAction(MyWellmark_OR.regbtn, "SCROLLANDCLICK", "");
	}
	public void extractdata(String sid) throws SQLException, ClassNotFoundException{
		String query = dataTable.getData("General_Data", "ExtractQuery");
		//sid = dataTable.getData("General_Data", "Username");
		query = query.replace("<<SBSB_ID>>", sid);
		//Newly added_Aravinth
		openDBConnection("jdbc:sqlserver://63.145.102.62:11001;" +  
				"databaseName=fawmkts1","WMKCN06643","Facets@2018");
		/////ResultSet rs = executeQuery(query);
		ResultSet rs = getRecordSet(query);
		
		
		try {
			while(rs.next()) {
				sbsbid = rs.getString("SBSB_ID").trim();
				lastname = rs.getString("SBSB_LAST_NAME").trim();
				firstname = rs.getString("SBSB_FIRST_NAME").trim();
				ssn = rs.getString("MEME_SSN").trim();
				dob = rs.getString("MEME_BIRTH_DT").trim();
				zipcode = rs.getString("SBAD_ZIP").trim();
				phone = rs.getString("SBAD_PHONE").trim();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (ssn!=null){
			ssn=ssn.substring(5, 9);
		}
		if (phone.equals("")){
			phone=phone.replace("", "6418427336");
		}
	}
	public void registerMember(){
		//Switching tabs
		ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
		System.out.println(tabs.size());
		if (tabs.size() > 0) {
			driver.switchTo().window(tabs.get(1));
		}
		
		if (driver.isElementvisible(By.xpath("//input[@id='ctl00_MainContent_btnNext']"))){
			performAction(MyWellmark_OR.wid, "SENDKEYS", sbsbid);
			performAction(MyWellmark_OR.fname, "SENDKEYS", firstname);
			performAction(MyWellmark_OR.lname, "SENDKEYS", lastname);
			selectValueFromDropdownForGivenId(MyWellmark_OR.relationship,1);
			performAction(MyWellmark_OR.ssn, "SENDKEYS", ssn);
			performAction(MyWellmark_OR.dob, "SENDKEYS", dob);
			performAction(MyWellmark_OR.zipcode, "SENDKEYS", zipcode);
			performAction(MyWellmark_OR.phone, "SENDKEYS", phone);
			String name = firstname.concat(lastname).concat("@").concat("wellmark.com");
			performAction(MyWellmark_OR.emailid, "SENDKEYS", name);
			performAction(MyWellmark_OR.nextbtn, "SCROLLANDCLICK", "");
			int state1 = driver.findElements(By.xpath("//p/strong[contains(text(),'STEP 2 of 2')]")).size();
			if(state1==1){
				report.updateTestLog("Registration First Step", "Registration First Step is completedly sucessfully", Status.PASS);
			}else
			{
				report.updateTestLog("Registration First Step", "Registration First Step is not completedly sucessfully", Status.FAIL);
			}
		}
	}
	public void registerMemberStep2(){
		int state = driver.findElements(By.xpath("//p/strong[contains(text(),'STEP 2 of 2')]")).size();
		if(state==1){
			String username = randomIdentifier();
			String Password = dataTable.getData("General_Data", "Password");
			String securityans = dataTable.getData("General_Data", "securityans");
			dataTable.putData("General_Data", "Username", username);
			/*String randomvalue= "kar";
			if(username!=null){
				username= username.concat(randomvalue);
			}*/  //DIUVVHMVYDIUVVHMVY
			performAction(MyWellmark_OR.userid, "SENDKEYS", username);
			performAction(MyWellmark_OR.passwd, "SENDKEYS", Password);
			performAction(MyWellmark_OR.confirmpasswd, "SENDKEYS", Password);
			selectValueFromDropdownForGivenId(MyWellmark_OR.securityques1,1);
			performAction(MyWellmark_OR.securityans1, "SENDKEYS", securityans);
			selectValueFromDropdownForGivenId(MyWellmark_OR.securityques2,2);
			performAction(MyWellmark_OR.securityans2, "SENDKEYS", securityans);
			driver.findElement(By.xpath("//input[@id='ctl00_MainContent_rbAcceptFraudStatementPersonal']")).sendKeys(Keys.SPACE);	
			driver.findElement(By.xpath("//input[@id='ctl00_MainContent_cbxAcceptTerms']")).sendKeys(Keys.SPACE);		
			performAction(MyWellmark_OR.submitbtn, "SCROLLANDCLICK", "");
			report.updateTestLog("Registration Second Step", "Registration Second Step is completedly sucessfully", Status.PASS);
		}
		else{
			report.updateTestLog("Registration Second Step", "Registration Second Step is not completedly sucessfully", Status.FAIL);
		}
		int state1 =driver.findElements(By.xpath("//h2[contains(text(),'Registration Successful')]")).size();
		performAction(MyWellmark_OR.continuebtn, "SCROLLANDCLICK", "");
		driver.waitTillPageLoaded();
		if(state1==1){
			report.updateTestLog("Registration", "Registration is completedly sucessfully", Status.PASS);
		}else{
			report.updateTestLog("Registration", "Registration is not completedly sucessfully", Status.FAIL);
		}
	}
	public void validateFutureEffMsg(){
		int policymsg = driver.findElements(By.xpath("//div[@class='panel-info-icon']//following::p[contains(text(),'You are viewing a policy that will begin soon.')]")).size();
		int benefitmsg = driver.findElements(By.xpath("//div[@class='panel-info-icon']//following::p[contains(text(),'Benefits and other coverage information are not available at this time.')]")).size();
		int welcomenote = driver.findElements(By.xpath("//h2[contains(text(),'WELCOME TO myWELLMARK!')]")).size();
		int doctorlink = driver.findElements(By.xpath("//a[@class='link-condensed link-icon link-icon-right']/span[contains(.,'Doctor')]")).size();
		int fcailitylink = driver.findElements(By.xpath("//a[@class='link-condensed link-icon link-icon-right']/span[contains(.,'Facility')]")).size();
		int pharmacylink = driver.findElements(By.xpath("//a[@class='link-condensed link-icon link-icon-right']/span[contains(.,'Pharmacy')]")).size();
		int dentistlink = driver.findElements(By.xpath("//a[@class='link-condensed link-icon link-icon-right']/span[contains(.,'Dentist')]")).size();
		if ((policymsg==1)&&(benefitmsg==1)&&(welcomenote==1)) {
			report.updateTestLog("Messages", "policymsg, benefitmsg, welcomenote is displayed sucessfully", Status.PASS);
		} else {
			report.updateTestLog("Messages", "policymsg, benefitmsg, welcomenote is not displayed sucessfully", Status.FAIL);
		}
		if ((doctorlink!=1)&&(fcailitylink!=1)&&(pharmacylink!=1)&&(dentistlink!=1)) {
			report.updateTestLog("Home Page", "Home Page is not displayed any widgets regarding benefits,claims,id card and Find care sucessfully", Status.PASS);
		} else {
			report.updateTestLog("Home Page", "Home Page is displayed any widgets regarding benefits,claims,id card and Find care sucessfully", Status.FAIL);
		}
	}
	public void checkHighPerformanceLink(){
		performAction(MyWellmark_OR.highperformancelink, "SCROLLANDCLICK", "");
		driver.waitTillPageLoaded();
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1)); 
		String currenturl = driver.getCurrentUrl();
		int state = driver.findElements(By.xpath("//h1[contains(text(),'Hy-Vee High Performance Network')]")).size();
		if (state==1){
			report.updateTestLog("High Performance network ", "System displayed PDF of their plan's provider directory succesfully", Status.PASS);
		}else
		{
			report.updateTestLog("High Performance network ", "System is not displayed PDF of their plan's provider directory succesfully", Status.FAIL);
		}	
	}
	public void CheckUiGradeCare(){
		performAction(MyWellmark_OR.findcarelink, "SCROLLANDCLICK", "");
		driver.waitTillPageLoaded();
		performAction(MyWellmark_OR.uigraedecategorylink, "SCROLLANDCLICK", "");
		driver.waitTillPageLoaded();
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1)); 
		String uigradeURL=dataTable.getData("General_Data", "uigradcare_url");
		String currenturl = driver.getCurrentUrl();
		int state = driver.findElements(By.xpath("//h1[contains(text(),'UIGRADCare Directory')]")).size();
		if ((state==1)&&(uigradeURL.contains(currenturl))){
			report.updateTestLog("UIGRADCare ", "System displayed UIGRADCare directory succesfully", Status.PASS);
		}else
		{
			report.updateTestLog("UIGRADCare ", "System is not displayed UIGRADCare directory succesfully", Status.FAIL);
		}
	}
	/* Praveen***********************/
		public void Changethepassword()
	{
		performAction(MyWellmark_OR.profile,"click","");
		driverUtil.waitFor(5000);
		int sizeedit=driver.findElements(MyWellmark_OR.passwordeditlink).size();

		if(sizeedit==1)
		{
			report.updateTestLog("Edit Link", "Click on Edit link near the username in ACCOUNT SECURITY widget", Status.PASS);	
		}
		else
		{
			report.updateTestLog("Edit Link", "Click on Edit link near the username in ACCOUNT SECURITY widget", Status.FAIL);
		}
		performAction(MyWellmark_OR.passwordeditlink,"SCROLLANDCLICK","");
		driverUtil.waitFor(5000);
		String newpassword = dataTable.getData("General_Data", "newpassword");
		String oldpassword = dataTable.getData("General_Data", "Password");
		driver.findElement(MyWellmark_OR.currentpwd).sendKeys(oldpassword);
		driver.findElement(MyWellmark_OR.newpwd).sendKeys(newpassword);
		driver.findElement(MyWellmark_OR.confirmpwd).sendKeys(newpassword);
		performAction(MyWellmark_OR.savebutton,"click","");
		driverUtil.waitFor(10000);
		int sizesucc=driver.findElements(MyWellmark_OR.passsuccessful).size();
		if(sizesucc==1)
		{
			report.updateTestLog("Change Password", "The confirmation message will be displayed in profile page for changing the Password", Status.PASS);
			dataTable.putData("General_Data", "Password", newpassword);
		}
		else
		{
			report.updateTestLog("Change Password", "The confirmation message will be displayed in profile page for changing the Password", Status.FAIL);
		}
	}
	public void Changetheusername()
	{
		performAction(MyWellmark_OR.profile,"click","");
		driverUtil.waitFor(5000);
		int sizeedit=driver.findElements(MyWellmark_OR.usernameeditlink).size();

		if(sizeedit==1)
		{
			report.updateTestLog("Edit Link", "Click on Edit link near the username in ACCOUNT SECURITY widget", Status.PASS);	
		}
		else
		{
			report.updateTestLog("Edit Link", "Click on Edit link near the username in ACCOUNT SECURITY widget", Status.FAIL);
		}

		performAction(MyWellmark_OR.usernameeditlink,"SCROLLANDCLICK","");
		driverUtil.waitFor(5000);
		String userName = dataTable.getData("General_Data", "Username");
		String password = dataTable.getData("General_Data", "Password");
		driver.findElement(MyWellmark_OR.verifypassword).sendKeys(password);
		driver.findElement(MyWellmark_OR.newuserid).sendKeys(userName);
		performAction(MyWellmark_OR.savebutton,"click","");
		driverUtil.waitFor(10000);
		int sizesucc=driver.findElements(MyWellmark_OR.useridsuccessful).size();
		if(sizesucc==1)
		{
			report.updateTestLog("Change Username", "The confirmation message will be displayed in profile page for changing the username", Status.PASS);	
		}
		else
		{
			report.updateTestLog("Change Username", "The confirmation message will be displayed in profile page for changing the username", Status.FAIL);
		}
	}
	public void error_message_invalidpwd()
	{
		performAction(MyWellmark_OR.profile,"click","");
		driverUtil.waitFor(5000);
		int sizeedit=driver.findElements(MyWellmark_OR.passwordeditlink).size();

		if(sizeedit==1)
		{
			report.updateTestLog("Edit Link", "Click on Edit link near the username in ACCOUNT SECURITY widget", Status.PASS);	
		}
		else
		{
			report.updateTestLog("Edit Link", "Click on Edit link near the username in ACCOUNT SECURITY widget", Status.FAIL);
		}
		performAction(MyWellmark_OR.passwordeditlink,"SCROLLANDCLICK","");
		driverUtil.waitFor(5000);
		String password = dataTable.getData("General_Data", "Password");
		String newpassword = dataTable.getData("General_Data", "newpassword");		
		driver.findElement(MyWellmark_OR.currentpwd).sendKeys(password);
		driver.findElement(MyWellmark_OR.newpwd).sendKeys(newpassword);
		driver.findElement(MyWellmark_OR.confirmpwd).sendKeys(newpassword);
		performAction(MyWellmark_OR.savebutton,"click","");
		
		List<WebElement> errormess=driver.findElements(MyWellmark_OR.pwderror);		
		String pwderrormessgae = dataTable.getData("General_Data", "invalidinputerror");
		String[] errormessageactual = new String[]{null,null};
		int i=0;
		for (WebElement errormess_Element : errormess) {
			errormessageactual[i]=errormess_Element.getText();
			i++;
		}
		if((errormessageactual[0].equals(pwderrormessgae)) && (errormessageactual[1].equals(pwderrormessgae)))
		{
			report.updateTestLog("Invalid Password error", "Error message is displayed for password: "+newpassword+" as "+pwderrormessgae, Status.PASS);	
		}
		else
		{
			report.updateTestLog("Invalid Password error", "Error message is not displayed for password: "+newpassword, Status.FAIL);
			
		}		
	}

	public void logoutmywellmark()
	{
		performAction(MyWellmark_OR.logoutbutton,"click","");
		driverUtil.waitFor(2000);
		//int logoutsize=driver.findElements(MyWellmark_OR.logoutpagetext).size();
		if(driver.isElementVisible(By.xpath("//button[contains(.,'Login')]")))
		{
			report.updateTestLog("Logout", "User must be logged out", Status.PASS);	
		}
		else
		{
			report.updateTestLog("Logout", "User is not logged out", Status.FAIL);
		}
		//		driver.manage().deleteAllCookies();
		//		driver.quit();
	}
	public void Error_message_for_invalid()
	{
		performAction(MyWellmark_OR.profile,"click","");
		driverUtil.waitFor(5000);
		int sizeedit=driver.findElements(MyWellmark_OR.usernameeditlink).size();
		if(sizeedit==1)
		{
			report.updateTestLog("Edit Link", "Click on Edit link near the username in ACCOUNT SECURITY widget", Status.PASS);	
		}
		else
		{
			report.updateTestLog("Edit Link", "Click on Edit link near the username in ACCOUNT SECURITY widget", Status.FAIL);
		}
		performAction(MyWellmark_OR.usernameeditlink,"SCROLLANDCLICK","");
		driverUtil.waitFor(5000);
		String password = dataTable.getData("General_Data", "Password");		
		String[] invalid=new String[]{"we2","rghwueirvygeyfgvnehfefhgvnbhfvbfsvsfnhbvehvbhfbvhbbgrbehr","abcdefghi@"};
		String useriderrormessgae = dataTable.getData("General_Data", "invalidinputerror");
		String errormessage[]=useriderrormessgae.split(";");

		int size=invalid.length;
		for(int i=0;i<size;i++)
		{
			driver.findElement(MyWellmark_OR.verifypassword).clear();
			driver.findElement(MyWellmark_OR.verifypassword).sendKeys(password);
			driver.findElement(MyWellmark_OR.newuserid).clear();
			driver.findElement(MyWellmark_OR.newuserid).sendKeys(invalid[i]);
			performAction(MyWellmark_OR.savebutton,"click","");
			String errormess=driver.findElement(MyWellmark_OR.useriderror).getText();

			if(errormessage[i].equals(errormess))
			{
				report.updateTestLog("Invalid user error", "Error message is displayed for username: "+invalid[i]+" as "+errormess, Status.PASS);	
			}
			else
			{
				report.updateTestLog("Invalid user error", "Error message is not displayed for username: "+invalid[i], Status.FAIL);
				break;
			}

		}
	}
	public void change_security_ques()
	{
		performAction(MyWellmark_OR.profile,"click","");
		driverUtil.waitFor(5000);
		int sizeedit=driver.findElements(MyWellmark_OR.securityquesedit).size();
		if(sizeedit==1)
		{
			report.updateTestLog("Edit Link", "Click on Edit link near the Security Questions in ACCOUNT SECURITY widget", Status.PASS);	
		}
		else
		{
			report.updateTestLog("Edit Link", "Click on Edit link near the Security Questions in ACCOUNT SECURITY widget", Status.FAIL);
		}
		performAction(MyWellmark_OR.securityquesedit,"SCROLLANDCLICK","");
		driverUtil.waitFor(5000);
		Random rand=new Random();
		int max=17,min=2;		
		int first=min+rand.nextInt(max-min+1);
		driver.findElement(By.xpath("//select[@id='securityQuestionOne']/option["+first+"]")).click();
		driver.findElement(MyWellmark_OR.secanswer1).sendKeys("wellmark");
		int second=2+rand.nextInt(17-2+1);
		if(first==second)
			second=min+rand.nextInt(max-min+1);
		driver.findElement(By.xpath("//select[@id='securityQuestionTwo']/option["+second+"]")).click();
		driver.findElement(MyWellmark_OR.secanswer2).sendKeys("wellmark");
		report.updateTestLog("Security Questions","Questions are  selected from the 'Security question #1/2' and answers are entered in 'Security answer #2'", Status.SCREENSHOT);
		performAction(MyWellmark_OR.savebutton,"click","");
		int sizesucc=driver.findElements(MyWellmark_OR.secquessuccessful).size();
		if(sizesucc==1)
		{
			report.updateTestLog("Change Security Question", "The confirmation message is  displayed in profile page for changing the security questions", Status.PASS);	
		}
		else
		{
			report.updateTestLog("Change Security Question", "The confirmation message is not displayed in profile page for changing the security questions", Status.FAIL);
		}			
	}
	public void  Error_message_securityques()
	{
		performAction(MyWellmark_OR.profile,"click","");
		driverUtil.waitFor(5000);
		int sizeedit=driver.findElements(MyWellmark_OR.securityquesedit).size();
		if(sizeedit==1)
		{
			report.updateTestLog("Edit Link", "Click on Edit link near the Security Questions in ACCOUNT SECURITY widget", Status.PASS);	
		}
		else
		{
			report.updateTestLog("Edit Link", "Click on Edit link near the Security Questions in ACCOUNT SECURITY widget", Status.FAIL);
		}
		performAction(MyWellmark_OR.securityquesedit,"SCROLLANDCLICK","");
		driverUtil.waitFor(5000);
		Random rand=new Random();
		int max=17,min=2;		
		int first=min+rand.nextInt(max-min+1);
		driver.findElement(By.xpath("//select[@id='securityQuestionOne']/option["+first+"]")).click();
		driver.findElement(MyWellmark_OR.secanswer1).sendKeys("wellmark");
		driver.findElement(By.xpath("//select[@id='securityQuestionTwo']/option["+first+"]")).click();
		driver.findElement(MyWellmark_OR.secanswer2).sendKeys("wellmark");
		report.updateTestLog("Security Questions","Same Questions are  selected in  the 'Security question #1/2'", Status.SCREENSHOT);
		performAction(MyWellmark_OR.savebutton,"click","");
		String errormessage = dataTable.getData("General_Data", "invalidinputerror");
		String errormess=driver.findElement(MyWellmark_OR.useriderror).getText();
		if(errormessage.equals(errormess))
			report.updateTestLog("Invalid user error", "Error message is displayed as : "+errormess, Status.PASS);	
		else	
			report.updateTestLog("Invalid user error", "Error message is not displayed as : "+errormess, Status.FAIL);
	}
	public void idcardvalidationcheckallmembers() 
	{
		String name=driver.findElement(MyWellmark_OR.welcomeText).getText();
		String firstName=name.substring(8);
		dataTable.putData("General_Data", "PolicyHolder_Name", firstName);
		performAction(MyWellmark_OR.myPlansLink,"SCROLLANDCLICK","");
		driverUtil.waitFor(5000);	
		driver.findElement(MyWellmark_OR.benefitPeriod).sendKeys(Keys.PAGE_DOWN);
		driverUtil.waitFor(2000);
		int sizeidcard=driver.findElements(MyWellmark_OR.viewidcardslink).size();
		if(sizeidcard==1)
		{
			report.updateTestLog("View ID Cards", "View ID card link is available", Status.PASS);
					
		}
		else
		{
			report.updateTestLog("Edit Link", "View ID card link is not available", Status.FAIL);
		}
		performAction(MyWellmark_OR.viewidcardslink,"SCROLLANDCLICK","");
		driverUtil.waitFor(5000);
		List<WebElement> idcardlinks=driver.findElements(MyWellmark_OR.IDcardsLink);
		int i=0;
		int sizenoofidcard=idcardlinks.size();
		String[] membernameslink=new String[sizenoofidcard];
		String[] membernamesidcard=new String[sizenoofidcard];
		if(sizenoofidcard!=0)
		{
		for (WebElement id : idcardlinks) 
		{
			membernameslink[i]=id.getText().split("\\n")[0];
			id.click();
			driverUtil.waitFor(3000);
			membernamesidcard[i]=driver.findElement(MyWellmark_OR.idcardname).getText().split("\\s+")[0]+" ".concat(driver.findElement(MyWellmark_OR.idcardname).getText().split("\\s+")[2]);
			if(membernameslink[i].equals(membernamesidcard[i]))
				report.updateTestLog("Member ID Cards", "ID card is displayed for Member "+i, Status.PASS);
			else
				report.updateTestLog("Member ID Cards", "ID card is displayed not  for Member "+i, Status.FAIL);				
			i++;
		}
		}
		else
		{
			String welcomeName=dataTable.getData("General_Data", "PolicyHolder_Name");
			String memberNamesIdCardOne= driver.findElement(MyWellmark_OR.idcardname).getText().split("\\s+")[0];
			if(welcomeName.equalsIgnoreCase(memberNamesIdCardOne))
				report.updateTestLog("Member ID Cards", "ID card is displayed for Member "+welcomeName, Status.PASS);
			else
				report.updateTestLog("Member ID Cards", "ID card is displayed not  for Member "+welcomeName, Status.FAIL);
		}
		}
	 	public void idcardfrontlayout()
	 	{	
 		List<WebElement> idcardlinks=driver.findElements(MyWellmark_OR.IDcardsLink);
 		if(idcardlinks.size()!=0)
 		{
		idcardlinks.get(0).click();	
		idcardlinks.get(0).sendKeys(Keys.ARROW_DOWN);
		idcardlinks.get(0).sendKeys(Keys.ARROW_DOWN);
		idcardlinks.get(0).sendKeys(Keys.ARROW_DOWN);
 		}
		int frontlogo=driver.findElements(MyWellmark_OR.idcardfrontlogo).size();
		int backlogo=driver.findElements(MyWellmark_OR.idcardbacklogo).size();
		if(frontlogo==1&&backlogo==1)
		{
			report.updateTestLog("BCBS Logo", " Blue Cross Blue shield Logo is displayed in the Front and back side of the ID card", Status.PASS);
					
		}
		else
		{
			report.updateTestLog("BCBS Logo", " Blue Cross Blue shield Logo is displayed in the Front and back side of the ID card", Status.FAIL);
		}
		String plancodedisp=driver.findElement(MyWellmark_OR.plancode).getText();
		String plancode = dataTable.getData("General_Data", "plancode");
		if(plancodedisp.equalsIgnoreCase(plancode))
		{
			report.updateTestLog("Plan Code", "Plan Code is  displayed in front of the ID card", Status.PASS);					
		}
		else
		{
			report.updateTestLog("Benefit Info", "Plan Code is   not displayed in front of the ID card", Status.FAIL);
		}		
		String benefittext=driver.findElement(MyWellmark_OR.benefitinfo).getText();
		String benefit = dataTable.getData("General_Data", "benefitinfo");
		if(benefittext.equalsIgnoreCase(benefit))
		{
			report.updateTestLog("Benefit Info", "Benefit Information content is  displayed in front of the ID card", Status.PASS);					
		}
		else
		{
			report.updateTestLog("Benefit Info", "Benefit Information content is  not displayed in front of the ID card", Status.FAIL);
		}		
		String rxbin = dataTable.getData("General_Data", "rxbin");
		String rxpcn = dataTable.getData("General_Data", "rxpcn");
		String rxgrp = dataTable.getData("General_Data", "rxgrp");
		String rxbindisp= driver.findElement(MyWellmark_OR.idcardBIN).getText();
		String rxpcndisp= driver.findElement(MyWellmark_OR.idcardPCN).getText();
		String rxgrpdisp= driver.findElement(MyWellmark_OR.idcardGrp).getText();
		if (rxbin.equalsIgnoreCase(rxbindisp)&&rxpcn.equalsIgnoreCase(rxpcndisp)&&rxgrp.equalsIgnoreCase(rxgrpdisp))
		{
			report.updateTestLog("Rx Details", " RxBIN, RxPCN and RxGrp Details are displayed  in Front of ID card ", Status.PASS);
					
		}
		else
		{
			report.updateTestLog("Rx Details", " RxBIN, RxPCN and RxGrp Details are not displayed  in Front of ID card", Status.FAIL);
		}
		String suitCaseText = dataTable.getData("General_Data", "suitCase");		
		int suitCaseSize=driver.findElements(By.xpath("//div[@class='panel dyk-panel id-card-linklist']//div[@class='id-card id-card-front']//img[@alt='"+suitCaseText+"']")).size();
		if(suitCaseSize==1)
		{
			report.updateTestLog("Suit Case Image", suitCaseText+"is displayed in the Front side of the ID card", Status.PASS);
					
		}
		else
		{
			report.updateTestLog("Suit Case Image", suitCaseText+" is not displayed in the Front  side of the ID card", Status.FAIL);
		}
		String Groupno=driver.findElement(MyWellmark_OR.idcardgroupno).getText();
		String wid=driver.findElement(MyWellmark_OR.idno).getText();
		dataTable.putData("General_Data", "Group_Number", Groupno);
		dataTable.putData("General_Data", "Wellmark_Id", wid);
		String memname=driver.findElement(MyWellmark_OR.idcardname).getText();
		dataTable.putData("General_Data", "PolicyHolder_Name", memname);			
	}
	 	public void idcardbacklayout()
	 	{
	 		String websitedisp=driver.findElement(MyWellmark_OR.website).getText();
	 		String website="www.wellmark.com";		 		
	 		String custno ="1-800-355-2031";
	 		String custnodisp=driver.findElement(MyWellmark_OR.custno).getText();
	 		int custSize=driver.findElements(MyWellmark_OR.custno).size();
	 		if (custSize==1&&website.equalsIgnoreCase(websitedisp) )
			{
				report.updateTestLog("Customer Service and Website", "Cus Service Number and website is displayed in Back of ID card", Status.PASS);
						
			}
			else
			{
				report.updateTestLog("Customer Service no", "Cus Service Number and website is not displayed in Back of ID card", Status.FAIL);
			}
	 		dataTable.putData("General_Data", "CustomerServiceNumber", custnodisp);
	 		String membertext=driver.findElement(MyWellmark_OR.instextmembers).getText();
	 		String provtext=driver.findElement(MyWellmark_OR.instextproviders).getText();
	 		String instext = dataTable.getData("General_Data", "instext");
	 		String insttextinp[]=instext.split(";");
	 		if(membertext.equalsIgnoreCase(insttextinp[0])&&provtext.equalsIgnoreCase(insttextinp[1]))
	 		{
				report.updateTestLog("Instructional Text", "Instructional Text for members and providers are  displayed in Back of ID card", Status.PASS);						
			}
			else
			{
				report.updateTestLog("Instructional Text", "Instructional Text for members and providers are not displayed in Back of ID card", Status.FAIL);			
			}	
	 		String rxtext=driver.findElement(MyWellmark_OR.rxindex).getText();
	 		String rxtextinp = dataTable.getData("General_Data", "rxidentext");
	 		if(rxtext.equalsIgnoreCase(rxtextinp))
	 		{
				report.updateTestLog("Rx Benefit  Mgr identification Text", "Rx Benefit  manager identification Text are  displayed in Back of ID card", Status.PASS);						
			}
			else
			{
				report.updateTestLog("Rx Benefit  Mgr identification Text", "Rx Benefit  manager identification Text are not displayed in Back of ID card", Status.FAIL);			
			}
	 		String entityTagline = dataTable.getData("General_Data", "entityTagline");
	 		String actualTaglinetext=driver.findElement(MyWellmark_OR.tagLine).getText();
	 		if(actualTaglinetext.equalsIgnoreCase(entityTagline))
	 		{
				report.updateTestLog("Entity Tagline", "Entity Tagline is  displayed in Back of ID card", Status.PASS);						
			}
			else
			{
				report.updateTestLog("Entity Taglinet", "Entity Tagline is  not displayed in Back of ID card", Status.FAIL);			
			}
	 	}
		public void idcardfrontlayout_synergy()
	 	{	
 		List<WebElement> idcardlinks=driver.findElements(MyWellmark_OR.IDcardsLink);
 		if(idcardlinks.size()!=0)
 		{
		idcardlinks.get(0).click();	
		idcardlinks.get(0).sendKeys(Keys.ARROW_DOWN);
		idcardlinks.get(0).sendKeys(Keys.ARROW_DOWN);
		idcardlinks.get(0).sendKeys(Keys.ARROW_DOWN);
 		}
		int frontlogo=driver.findElements(MyWellmark_OR.idcardfrontlogo).size();
		int backlogo=driver.findElements(MyWellmark_OR.idcardbacklogo).size();
		if(frontlogo==1&&backlogo==1)
		{
			report.updateTestLog("BCBS Logo", " Blue Cross Blue shield Logo is displayed in the Front and back side of the ID card", Status.PASS);
					
		}
		else
		{
			report.updateTestLog("BCBS Logo", " Blue Cross Blue shield Logo is displayed in the Front and back side of the ID card", Status.FAIL);
		}
		String plancodedisp=driver.findElement(MyWellmark_OR.plancode).getText();
		String plancode = dataTable.getData("General_Data", "plancode");
		if(plancodedisp.equalsIgnoreCase(plancode))
		{
			report.updateTestLog("Plan Code", "Plan Code is  displayed in front of the ID card", Status.PASS);					
		}
		else
		{
			report.updateTestLog("Benefit Info", "Plan Code is   not displayed in front of the ID card", Status.FAIL);
		}		
		String benefittext=driver.findElement(MyWellmark_OR.benefitinfo).getText();
		String benefit = dataTable.getData("General_Data", "benefitinfo");
		if(benefittext.equalsIgnoreCase(benefit))
		{
			report.updateTestLog("Benefit Info", "Benefit Information content is  displayed in front of the ID card", Status.PASS);					
		}
		else
		{
			report.updateTestLog("Benefit Info", "Benefit Information content is  not displayed in front of the ID card", Status.FAIL);
		}		
		String rxbin = dataTable.getData("General_Data", "rxbin");
		String rxpcn = dataTable.getData("General_Data", "rxpcn");
		String rxgrp = dataTable.getData("General_Data", "rxgrp");
		String rxbindisp= driver.findElement(MyWellmark_OR.idcardBIN).getText();
		String rxpcndisp= driver.findElement(MyWellmark_OR.idcardPCN).getText();
		String rxgrpdisp= driver.findElement(MyWellmark_OR.idcardGrp).getText();
		if (rxbin.equalsIgnoreCase(rxbindisp)&&rxpcn.equalsIgnoreCase(rxpcndisp)&&rxgrp.equalsIgnoreCase(rxgrpdisp))
		{
			report.updateTestLog("Rx Details", " RxBIN, RxPCN and RxGrp Details are displayed  in Front of ID card ", Status.PASS);
					
		}
		else
		{
			report.updateTestLog("Rx Details", " RxBIN, RxPCN and RxGrp Details are not displayed  in Front of ID card", Status.FAIL);
		}
		int nosuitcaseimage=driver.findElements(MyWellmark_OR.suitCaseCheck).size();
		if(nosuitcaseimage==1)
		{
			report.updateTestLog("Suit Case Image","No suitcase image is displayed in the Front side of the ID card", Status.PASS);
					
		}
		else
		{
			report.updateTestLog("Suit Case Image", "Suitcase image displayed in the Front  side of the ID card", Status.FAIL);
		}
		String Groupno=driver.findElement(MyWellmark_OR.idcardgroupno).getText();
		String wid=driver.findElement(MyWellmark_OR.idno).getText();
		dataTable.putData("General_Data", "Group_Number", Groupno);
		dataTable.putData("General_Data", "Wellmark_Id", wid);
		String memname=driver.findElement(MyWellmark_OR.idcardname).getText();
		dataTable.putData("General_Data", "PolicyHolder_Name", memname);			
	}
	 	public void invokeEVBI()
	 	{
	 		String evbiurl=dataTable.getData("General_Data", "EVBI_Url");
	 		String LoginPageTitle=dataTable.getData("General_Data", "LoginPage");
	 		driver.navigate().to(evbiurl);
	 		String PageTitleLoaded = driver.getTitle();
	 		if (PageTitleLoaded.equals(LoginPageTitle)) {
	 			report.updateTestLog("Invoke Application - EVBI", "Invoke Application Successful", Status.PASS);
	 		} 
	 		else {
	 			report.updateTestLog("Invoke Application - EVBI", "Invoke Application Unsuccessful", Status.FAIL);
	 		}
	 		String userName=dataTable.getData("General_Data", "EVBI_UserName");
	 		String usercred[]=userName.split(";");
	 		driver.findElement(MyWellmark_OR.txtUsername).sendKeys(usercred[0]);
	 		driver.findElement(MyWellmark_OR.txtPassword).sendKeys(usercred[1]);
	 		performAction(MyWellmark_OR.btnLogin, "SCROLLANDCLICK","" );
	 		if (MyWellmark_OR.welcomeevbi != null) {
	 			report.updateTestLog("Login Application", "Login Successful", Status.PASS);
	 		} else {
	 			report.updateTestLog("Login Application", "Login not Successful", Status.FAIL);
	 		}
	 	}
	 	public void validateEVBI_MemberDetails()
	 	{
	 		String memberIdText=dataTable.getData("General_Data", "Wellmark_Id");
			String memberName=dataTable.getData("General_Data", "PolicyHolder_Name");
			String groupNumber=dataTable.getData("General_Data", "Group_Number");
			String wellmarkId=dataTable.getData("General_Data", "Wellmark_Id");
			String customerServiceNumber=dataTable.getData("General_Data", "CustomerServiceNumber");
			String memberId=memberIdText.substring(3);			
			performAction(MyWellmark_OR.membreno,"SENDKEYS",memberId);
	 		performAction(MyWellmark_OR.searchbutton,"click","");
			driverUtil.waitFor(10000);
			int tablesize=driver.findElements(By.xpath("//td/font[contains(text(),'Active Contracts for Search Date')]/following::tbody[1]/tr")).size();
			for (int i=2;i<=tablesize;i++)
			{
				String policyhldtext=driver.findElement(By.xpath("//td/font[contains(text(),'Active Contracts for Search Date')]/following::tbody[1]/tr["+i+"]/td[5]")).getText();
				if(policyhldtext.equalsIgnoreCase("Policy Holder"))
				{
					WebElement emplink =driver.findElement(By.xpath("//td/font[contains(text(),'Active Contracts for Search Date')]/following::tbody[1]/tr["+i+"]/td[1]/a"));
					int empSize=driver.findElements(By.xpath("//td/font[contains(text(),'Active Contracts for Search Date')]/following::tbody[1]/tr["+i+"]/td[1]/a")).size();
					if(empSize==1)
					{
					emplink.click();
					break;
					}
					else
					report.updateTestLog("Member Link", "Member Link is not visible", Status.FAIL);
				}
			}
			//driver.findElement(By.xpath("(//td/font[contains(text(),'Active Contracts for Search Date')]/following::a[contains(text(),'"+memberName+"')])[1]")).click();
			driverUtil.waitFor(15000);			
			String memberName_EVBI=driver.findElement(MyWellmark_OR.membername).getText().trim();
			String wellmarkId_EVBI=driver.findElement(MyWellmark_OR.policyholderid).getText().replace(" ", "");
			String groupNumberText_EVBI=driver.findElement(MyWellmark_OR.groupno).getText().trim();
			String customerServiceNumber_EVBI=driver.findElement(MyWellmark_OR.customerno).getText().trim();
			String groupNumber_EVBI=groupNumberText_EVBI.split("-")[0];
			
			if(customerServiceNumber.equalsIgnoreCase(customerServiceNumber_EVBI)){
				report.updateTestLog("Customer Service Number Check", "Customer Service number present in the myWellmark   matches with EVBI", Status.PASS);
			}
 			else {
 				report.updateTestLog("Customer Service Number Check", "Customer Service number present in the myWellmark  doesnt matches with EVBI", Status.FAIL);
 			}
			if(memberName.equalsIgnoreCase(memberName_EVBI)){
				report.updateTestLog("Member Name", "Member Name present in the myWellmark   matches with EVBI", Status.PASS);
			}
 			else {
 				report.updateTestLog("Member Name", "Member Name present in the myWellmark  doesnt matches with EVBI", Status.FAIL);
 			}
			if(wellmarkId.equalsIgnoreCase(wellmarkId_EVBI)){
				report.updateTestLog("WellmarkId", "WellmarkId present in the myWellmark   matches with EVBI", Status.PASS);
			}
 			else {
 				report.updateTestLog("WellmarkId", "WellmarkId present in the myWellmark  doesnt matches with EVBI", Status.FAIL);
 			}
			if(groupNumber.equalsIgnoreCase(groupNumber_EVBI)){
				report.updateTestLog("Group Number", "Group Number present in the myWellmark   matches with EVBI", Status.PASS);
			}
 			else {
 				report.updateTestLog("Group Number", "Group Number present in the myWellmark  doesnt matches with EVBI", Status.FAIL);
 			}
	 	}
	public String findSubscriber() throws ClassNotFoundException, SQLException{
		String query = dataTable.getData("General_Data", "TestCase_Query");
		ArrayList<String> subscriberList = new ArrayList<String>();
		ResultSet result1 = executeQuery(query);
		String subsId = null;
		while(result1.next()){
			subscriberList.add(result1.getString("SBSB_ID"));
		}
		String mangoDBQuery = dataTable.getData("General_Data", "MangoDB_Query");
		for(int i=0;i<subscriberList.size();i++){
			mangoDBQuery.replace("<<SBSB_ID>>", subscriberList.get(i));
			ResultSet result2 = executeQuery(mangoDBQuery);
			while(result2.next()){
			subsId = result2.getString("SBSB_ID").trim();
			if(subsId.equals(subscriberList.get(i).trim())){
				break;
			}
			}
		}
		return subsId;
	}
	public void dentalIdCard_FrontSideValidation(){
		if(driver.isElementVisible(MyWellmark_OR.dental_IdCardFrontLogo)){
			report.updateTestLog("BCBS Logo", " Blue Cross Blue shield Logo is displayed in the Front side of the ID card", Status.PASS);
		}
		else
		{
			report.updateTestLog("BCBS Logo", " Blue Cross Blue shield Logo is not displayed in the Front side of the ID card", Status.FAIL);
		}
		String memberName=driver.findElement(MyWellmark_OR.dental_IdCardName).getText();
		if(memberName!=null){
			dataTable.putData("General_Data", "PolicyHolder_Name", memberName);
			report.updateTestLog("PolicyHolderName", "PolicyHolderName is displayed in the Front side of the ID card", Status.PASS);
		}
		else
		{
			report.updateTestLog("PolicyHolderName", "PolicyHolderName is not displayed in the Front side of the ID card", Status.FAIL);
		}
		String wellmark_Id=driver.findElement(MyWellmark_OR.dental_IdNo).getText();
		if(wellmark_Id!=null){
			dataTable.putData("General_Data", "Wellmark_Id", wellmark_Id);
			report.updateTestLog("Wellmark ID", "Wellmark ID is displayed in the Front side of the ID card", Status.PASS);
		}
		else
		{
			report.updateTestLog("Wellmark ID", "Wellmark ID is not displayed in the Front side of the ID card", Status.FAIL);
		}
		String groupNumber=driver.findElement(MyWellmark_OR.dental_IdCardGroupNo).getText();
		if(groupNumber!=null){
			dataTable.putData("General_Data", "Group_Number", groupNumber);
			report.updateTestLog("Group Number", "Group Number is displayed in the Front side of the ID card", Status.PASS);
		}
		else
		{
			report.updateTestLog("Group Number", "Group Number is not displayed in the Front side of the ID card", Status.FAIL);
		}
		String planCodeDisplayed=driver.findElement(MyWellmark_OR.dental_IdCardPlanCode).getText();
		String plancode = dataTable.getData("General_Data", "plancode");
		if(planCodeDisplayed.equalsIgnoreCase(plancode)){
			report.updateTestLog("Plan Code", "Plan Code is displayed in the Front side of the ID card", Status.PASS);
		}
		else
		{
			report.updateTestLog("Plan Code", "Plan Code is not displayed in the Front side of the ID card", Status.FAIL);
		}
		String benefitInfo=driver.findElement(MyWellmark_OR.dental_BenefitInfo).getText();
		if(benefitInfo!=null){
			report.updateTestLog("Benefit Information", "Benefit Information is displayed in the Front side of the ID card", Status.PASS);
		}
		else
		{
			report.updateTestLog("Benefit Information", "Benefit Information is not displayed in the Front side of the ID card", Status.FAIL);
		}
		if(driver.isElementVisible(MyWellmark_OR.dental_SuitCaseImage)){
			report.updateTestLog("SuitCase Image", "SuitCase Image is displayed in the Front side of the ID card", Status.PASS);
		}
		else
		{
			report.updateTestLog("SuitCase Image", "SuitCase Imageo is not displayed in the Front side of the ID card", Status.FAIL);
		}
	}
	public void dentalIdCard_BackSideValidation(){
		if(driver.isElementVisible(MyWellmark_OR.dental_IdCardBackLogo)){
			report.updateTestLog("BCBS Logo", " Blue Cross Blue shield Logo is displayed in the Back side of the ID card", Status.PASS);
		}
		else
		{
			report.updateTestLog("BCBS Logo", " Blue Cross Blue shield Logo is not displayed in the Back side of the ID card", Status.FAIL);
		}
		if(driver.isElementVisible(MyWellmark_OR.dental_Website)){
			report.updateTestLog("Wellmark URL", "Wellmark URL is displayed in the Back side of the ID card", Status.PASS);
		}
		else
		{
			report.updateTestLog("Wellmark URL", "Wellmark URL is not displayed in the Back side of the ID card", Status.FAIL);
		}
		if(driver.isElementVisible(MyWellmark_OR.dental_CustNo)){
			String customerServiceNumber = driver.findElement(MyWellmark_OR.dental_CustNo).getText();
			dataTable.putData("General_Data", "CustomerServiceNumber", customerServiceNumber);
			report.updateTestLog("Customer Service Number", "Customer Service Number is displayed in the Back side of the ID card", Status.PASS);
		}
		else
		{
			report.updateTestLog("Customer Service Number", "Customer Service Number is not displayed in the Back side of the ID card", Status.FAIL);
		} 
		if(driver.isElementVisible(MyWellmark_OR.dental_InsTextMembers) && driver.isElementVisible(MyWellmark_OR.dental_InsTextProviders)){
			report.updateTestLog("Instruction text", " Instruction text for Members/Providers is displayed in the Back side of the ID card", Status.PASS);
		}
		else
		{
			report.updateTestLog("Instruction text", " Instruction text for Members/Providers is not displayed in the Back side of the ID card", Status.FAIL);
		}
		if(driver.isElementVisible(MyWellmark_OR.dental_TagLine)){
			report.updateTestLog("Entity TagLine", "Entity TagLine is displayed in the Back side of the ID card", Status.PASS);
		}
		else
		{
			report.updateTestLog("Entity TagLine", "Entity TagLine is not displayed in the Back side of the ID card", Status.FAIL);
		} 
	}
	public String randomIdentifier() {
		final String lexicon = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		final java.util.Random rand = new java.util.Random();
		// consider using a Map<String,Boolean> to say whether the identifier is being used or not 
		final Set<String> identifiers = new HashSet<String>();
	    StringBuilder builder = new StringBuilder();
	    while(builder.toString().length() == 0) {
	        int length = rand.nextInt(5)+5;
	        for(int i = 0; i < length; i++) {
	            builder.append(lexicon.charAt(rand.nextInt(lexicon.length())));
	        }
	        if(identifiers.contains(builder.toString())) {
	            builder = new StringBuilder();
	        }
	    }
	    return builder.toString();
	}
}


