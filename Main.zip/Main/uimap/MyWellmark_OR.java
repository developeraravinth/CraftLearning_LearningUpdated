package uimap;
import org.openqa.selenium.By;
public class MyWellmark_OR {
	
	public static final By txtUsername = By.xpath("//label[contains(.,'User ID')]/following-sibling::input");
	public static final By txtPassword = By.xpath("//label[contains(.,'Password')]/following-sibling::input");
	public static final By btnLogin = By.xpath("//input[@value='Log In']");
	public static final By wellmarkassessment=By.xpath("//h1[contains(text(),'Complete Wellness Assessment')]");
	public static final By continuetomywellmark=By.xpath("//a[contains(text(),'Continue to myWellmark')]");
	public static final By welcome = By.xpath("//h1[contains(text(),'Welcome')]");
	public static final By claimsLink = By.xpath("//div[@class='sidenav']//li[2]/a/span/span");
	public static final By statusOption = By.xpath("//*[@id='cf-Status']/option");
	public static final By statusDrp = By.xpath("//*[@id='cf-Status']");
	public static final By claims = By.xpath("//div[@class='claims-list ng-star-inserted']");
	public static final By paidDate = By.xpath("//p[@class='field-label ng-star-inserted']");
	public static final By patientName = By.xpath("//span[contains(text(),'Patient:')]");
	public static final By youPay = By.xpath("//span[contains(text(),'You Pay:')]");
	public static final By status = By.xpath("//span[contains(text(),'Status:')]");
	public static final By sortDrp = By.xpath("//*[@id='acSort']");
	public static final By claimStatus = By.xpath("//p[@class='ng-star-inserted']/span[3]");
	public static final By myWellmark=By.xpath("//a[contains(.,'Continue to myWellmark')]");
	//public static final By myWellmark=By.xpath("//*[@class='btn-row']/a[2]");
	public static final By claimDetailsLink = By.xpath("(//a[@class='claim-link ng-star-inserted'])[1]");
	public static final By expandCostDetails = By.xpath("//a[@class='link-icon view-toggle hidden-print ng-star-inserted']");
	public static final By claimNumber = By.xpath("//div[@class='content-header has-print ng-star-inserted']/h1");
	public static final By amountBilled = By.xpath("(//span[@class='amount'])[1]");
	public static final By deductible = By.xpath("(//span[@class='amount'])[2]");
	public static final By Copay = By.xpath("(//span[@class='amount'])[3]");
	public static final By Coinsurance = By.xpath("(//span[@class='amount'])[4]");
	public static final By AmountNotCovered = By.xpath("(//span[@class='amount'])[5]");
	public static final By wellmarkDiscount = By.xpath("//span[@class='amount text-purple']");
	public static final By wellmarkPaid = By.xpath("//span[@class='amount text-green']");
	public static final By youPayClaim = By.xpath("//span[@class='amount text-primary']");
	
	
	public static final By memberId_CSI =By.xpath("//*[@id='txtMemberId']");
	public static final By buttonSearch_CSI =By.xpath("//*[@id='ContentPlaceHolder1_ClaimSearchCriteria1_btnSearch']");
	public static final By claimNumber_CSI =By.xpath("//*[@id='ContentPlaceHolder1_ClaimSearchCriteria1_txtClaimNumber']");
	public static final By claimLink_CSI =By.xpath("//a[@id='ContentPlaceHolder1_ClaimResultsGrid_dgResults_aClaimNumber_0']");
	public static final By claimSummary_CSI =By.xpath("//table[@id='ContentPlaceHolder1_tblSummaryAmount']/tbody/tr");
	public static final By deniedClaimReason = By.xpath("//div[@class='popover-content']");
	public static final By deniedClaim = By.xpath("(//a[@class='text-red'])[1]");
	
	
	public static final By myPlansLink = By.xpath("//div[@class='sidenav']//li[6]/a/span/span");
	public static final By welcomeText=By.xpath("//div[@class='content-container home-content']//h1");
	public static final By viewIdCard = By.xpath("//a[contains(text(),'View ID Cards')]");
	public static final By medicalCard = By.xpath("//h2[contains(text(),'Medical')]");
	public static final By dentalCard = By.xpath("//h2[contains(text(),'Dental')]");
	public static final By dental_IdCardFrontSide = By.xpath("//div[@class='panel dyk-panel']//div[@class='id-card id-card-front']");
	public static final By dental_IdCardBackSide = By.xpath("//div[@class='panel dyk-panel']//div[@class='id-card id-card-back-dental']");
	public static final By dentalOrderButton = By.xpath("(//h2[contains(text(),'Dental')]/parent::div/div)[2]/button[contains(text(),'Order')]");
	public static final By medicalOrderButton = By.xpath("(//h2[contains(text(),'Medical')]/parent::div/div)[2]/button[contains(text(),'Order')]");
	
	
	
	
	//C85 Karthik
	public static final By myplanlink = By.xpath("//a/span/span[contains(text(),'My Plans')]");
	public static final By findcarelink = By.xpath("//a/span/span[contains(text(),'Find Care')]");
	public static final By doctorlink = By.xpath("//a[@class='link-condensed link-icon link-icon-right']/span[contains(.,'Find a Provider')]");
	public static final By fcailitylink = By.xpath("//a[@class='link-condensed link-icon link-icon-right']/span[contains(.,'Facility')]");
	public static final By pharmacylink = By.xpath("//a[@class='link-condensed link-icon link-icon-right']/span[contains(.,'Pharmacy')]");
	public static final By dentistlink = By.xpath("//a[@class='link-condensed link-icon link-icon-right']/span[contains(.,'Dentist')]");
	public static final By doctorcontinuebtn = By.xpath("//div[@aria-hidden='false']//div[@class='modal-body']//a[contains(.,'Continue')]");
	public static final By doctorcancelbtn = By.xpath("//app-wm-content[@ng-reflect-content-title='Healthsparq - Find a Doctor']//following::div[@class='modal-actions']/a[contains(text(),'Cancel')]");
	public static final By facilitycontinuebtn = By.xpath("//div[@aria-hidden='false']//div[@class='modal-body']//a[contains(.,'Continue')]");
	public static final By faclitycancelbtn = By.xpath("//app-wm-content[@ng-reflect-content-title='Healthsparq - Find a Facility']//following::div[@class='modal-actions']/a[contains(text(),'Cancel')]");
	public static final By pharmacycontinuebtn = By.xpath("//div[@aria-hidden='false']//div[@class='modal-body']//a[contains(.,'Continue')]");
	public static final By pharmacycancelbtn = By.xpath("//div[@aria-labelledby='findAPharmacyModal']//a[contains(.,'Cancel')]");
	public static final By claimslink = By.xpath("//a/span/span[contains(text(),'Claims')]");
	public static final By usertype = By.xpath("//select[@id='ctl00_body_ddlRegisterNow']");
	public static final By regbtn = By.xpath("//a[contains(.,'Register')]");
	public static final By wid = By.xpath("//input[@id='ctl00_MainContent_txtIdentificationNumber']");
	public static final By fname = By.xpath("//input[@id='ctl00_MainContent_txtFirstName']");
	public static final By lname = By.xpath("//input[@id='ctl00_MainContent_txtLastName']");
	public static final By relationship = By.xpath("//select[@id='ctl00_MainContent_ddlRelationship']");
	public static final By dob = By.xpath("//input[@id='ctl00_MainContent_txtDateOfBirth']");
	public static final By ssn = By.xpath("//input[@id='ctl00_MainContent_txtLast4SSN']");
	public static final By zipcode = By.xpath("//input[@id='ctl00_MainContent_txtZipCode']");
	public static final By phone = By.xpath("//input[@id='ctl00_MainContent_txtPhoneNumber']");
	public static final By nextbtn = By.xpath("//input[@id='ctl00_MainContent_btnNext']");
	public static final By emailid = By.xpath("//input[@id='ctl00_MainContent_txtEmailAddress']");
	public static final By highperformancelink = By.xpath("//a[@class='link-condensed link-icon link-icon-right']/span[contains(text(),'High Performance Network')]");
	public static final By uigraedecategorylink = By.xpath("//a[@class='link-condensed link-icon link-icon-right']/span[contains(text(),'UIGRADCare Directory')]");
	public static final By userid = By.xpath("//input[@id='ctl00_MainContent_txtUserId']");
	public static final By passwd = By.xpath("//input[@id='ctl00_MainContent_txtPassword']");
	public static final By confirmpasswd = By.xpath("//input[@id='ctl00_MainContent_txtPasswordConfirm']");
	public static final By securityques1 = By.xpath("//select[@id='ctl00_MainContent_ddlSecurityQuestion1']");
	public static final By securityques2 = By.xpath("//select[@id='ctl00_MainContent_ddlSecurityQuestion2']");
	public static final By securityans1 = By.xpath("//input[@id='ctl00_MainContent_txtSecurityQuestion1Answer']");
	public static final By securityans2 = By.xpath("//input[@id='ctl00_MainContent_txtSecurityQuestion2Answer']");
	public static final By cerifyidentity = By.xpath("//input[@id='ctl00_MainContent_rbAcceptFraudStatementPersonal']");
	public static final By termscondition = By.xpath("//input[@id='ctl00_MainContent_cbxAcceptTerms']");
	public static final By submitbtn = By.xpath("//input[@id='ctl00_MainContent_btnSubmit']");
	public static final By regsucessmsg = By.xpath("//h2[contains(text(),'Registration Successful')]");
	public static final By continuebtn = By.xpath("//input[@id='ctl00_MainContent_btnContinue']");
/*Praveen ******************************/
	/*Login Page */
	public static final By txtUserID=By.id("ctl00_body_userid");
	public static final By txtPswd=By.id("ctl00_body_password");
	public static final By loginbtn=By.id("ctl00_body_btnOk");
	public static final By mywellmarklogo=By.xpath("//img[@alt='MyWellmark Homepage']");
	/*Home Page*/
	public static final By profile=By.xpath("(//a/span[contains(text(),'Profile')])[1]");
	/*Profile Page*/
	public static final By usernameeditlink=By.xpath("(//div/h2[contains(text(),'Account Security')]//following::div[starts-with(@class,'account-info-row')]/a)[1]");
	public static final By passwordeditlink=By.xpath("(//div/h2[contains(text(),'Account Security')]//following::div[starts-with(@class,'account-info-row')]/a)[2]");
	public static final By securityquesedit=By.xpath("(//div/h2[contains(text(),'Account Security')]//following::div[starts-with(@class,'account-info-row')]/a)[3]");
	/*Security Questions Edit Page*/
	public static final By secanswer1=By.xpath("//label[contains(text(),'Security Answer #1')]//following-sibling::input");
	public static final By secanswer2=By.xpath("//label[contains(text(),'Security Answer #2')]//following-sibling::input");
	public static final By secquessuccessful=By.xpath("//span[contains(text(),'Your security questions were successfully changed.')]");
	/*user Name Edit Page*/
	public static final By verifypassword=By.id("password");
	public static final By newuserid=By.id("newUserID");
	public static final By savebutton=By.xpath("//button[contains(text(),'Save')]");
	public static final By logoutbutton=By.xpath("(//span[contains(text(),'Log Out')])[1]");
	public static final By logoutpagetext=By.xpath("//span[contains(text(),'Your session has ended')]");
	public static final By useridsuccessful=By.xpath("//span[contains(text(),'Your user ID was successfully changed.')]");
	public static final By useriderror=By.xpath("//button[contains(text(),'Save')]/preceding::div[@class='help-block']");
	/*Edit Password Page*/
	public static final By currentpwd=By.id("password");
	public static final By newpwd=By.id("newPassword");
	public static final By confirmpwd=By.id("newPasswordConfirmation");
	public static final By passsuccessful=By.xpath("//span[contains(text(),'Your password was successfully changed.')]");
	public static final By pwderror=By.xpath("//button[contains(text(),'Save')]/preceding::div[@class='help-block']");
	//C85 Claims
	/*My Plans Page*/
	public static final By viewidcardslink=By.xpath("//div/h2[contains(text(),'My ID Card')]//following::a[contains(text(),'View ID Cards')]");
	public static final By benefitPeriod=By.xpath("//label[contains(text(),'Benefit Period')]/a");
	/*Medical ID Cards Page*/
	public static final By IDcardsLink=By.xpath("//div[@class='col-sm-6']/a[2]");
	public static final By idcardname=By.xpath("(//div[@class='panel dyk-panel id-card-linklist']//strong)[1]");
	public static final By idno=By.xpath("(//div[@class='panel dyk-panel id-card-linklist']//strong)[2]");
	public static final By lin1=By.xpath("//a[@href='/my-plans/id-card'][1]");
	public static final By idcardfrontlogo=By.xpath("//div[@class='panel dyk-panel id-card-linklist']//div[@class='id-card id-card-front']//img[@alt='Blue Cross� Blue Shield�']");
	public static final By idcardbacklogo=By.xpath("//div[@class='panel dyk-panel id-card-linklist']//div[@class='id-card id-card-back']//img[@alt='Blue Cross� Blue Shield�']");
	public static final By suitCaseImage=By.xpath("//div[@class='panel dyk-panel id-card-linklist']//div[@class='id-card id-card-front']//img[@alt='A suitcase symbol containing the letters PPO']");
	public static final By suitCaseCheck=By.xpath("//div[@class='panel dyk-panel id-card-linklist']//div[@class='id-card id-card-front']//img");
	public static final By blankSuitCaseImage=By.xpath("//div[@class='panel dyk-panel id-card-linklist']//div[@class='id-card id-card-front']//img[@alt='A suitcase symbol containing no text or symbols']");
	public static final By idcardplancode=By.xpath("//div[@class='panel dyk-panel id-card-linklist']//div[@class='id-card id-card-front']//th[contains(text(),'Plan Code')]//following-sibling::td");
	public static final By idcardgroupno=By.xpath("//div[@class='panel dyk-panel id-card-linklist']//div[@class='id-card id-card-front']//th[contains(text(),'Group No')]//following-sibling::td");
	public static final By idcardBIN=By.xpath("//div[@class='panel dyk-panel id-card-linklist']//div[@class='id-card id-card-front']//th[contains(text(),'RxBIN')]//following-sibling::td");
	public static final By idcardPCN=By.xpath("//div[@class='panel dyk-panel id-card-linklist']//div[@class='id-card id-card-front']//th[contains(text(),'RxPCN')]//following-sibling::td");
	public static final By idcardGrp=By.xpath("//div[@class='panel dyk-panel id-card-linklist']//div[@class='id-card id-card-front']//th[contains(text(),'RxGrp')]//following-sibling::td");
	public static final By plancode=By.xpath("//div[@class='panel dyk-panel id-card-linklist']//div[@class='id-card id-card-front']//th[contains(text(),'Plan Code')]//following-sibling::td");
	public static final By benefitinfo=By.xpath("//div[@class='col-idc full-info']");
	public static final By website=By.xpath("(//div[@class='panel dyk-panel id-card-linklist']//div[@class='id-card id-card-back']//strong)[1]");
	public static final By tagline=By.xpath("//div[@class='panel dyk-panel id-card-linklist']//div[@class='id-card id-card-back']//p[3]");
	public static final By instextmembers=By.xpath("(//div[@class='panel dyk-panel id-card-linklist']//div[@class='id-card id-card-back']//p)[1]");
	public static final By instextproviders=By.xpath("(//div[@class='panel dyk-panel id-card-linklist']//div[@class='id-card id-card-back']//p)[2]");
	public static final By tagLine=By.xpath("(//div[@class='panel dyk-panel id-card-linklist']//div[@class='id-card id-card-back']//p)[3]");
	public static final By custno=By.xpath("//div[@class='panel dyk-panel id-card-linklist']//div[@class='id-card id-card-back']//p[contains(text(),'Customer Service: ')]//following-sibling::strong");
	public static final By rxindex=By.xpath("(//div[@class='panel dyk-panel id-card-linklist']//div[@class='id-card id-card-back']//div[@class='row-idc'])[3]");
	//Dental ID Card
	public static final By dental_IdCardName=By.xpath("(//div[@class='panel dyk-panel']//strong)[1]");
	public static final By dental_IdNo=By.xpath("(//div[@class='panel dyk-panel']//strong)[2]");
	public static final By dental_IdCardFrontLogo=By.xpath("//div[@class='panel dyk-panel']//div[@class='id-card id-card-front']//img[@alt='Blue Cross� Blue Shield�']");
	public static final By dental_IdCardBackLogo=By.xpath("//div[@class='panel dyk-panel']//div[@class='id-card id-card-back-dental']//img[@alt='Blue Cross� Blue Shield�']");
	public static final By dental_SuitCaseImage=By.xpath("//div[@class='panel dyk-panel']//div[@class='id-card id-card-front']//img[@alt='A suitcase symbol containing the letters PPO']");
	public static final By dental_IdCardPlanCode=By.xpath("//div[@class='panel dyk-panel']//div[@class='id-card id-card-front']//th[contains(text(),'Plan Code')]//following-sibling::td");
	public static final By dental_IdCardGroupNo=By.xpath("//div[@class='panel dyk-panel']//div[@class='id-card id-card-front']//th[contains(text(),'Group No')]//following-sibling::td");
	public static final By dental_BenefitInfo=By.xpath("//div[@class='panel dyk-panel']//div[@class='id-card id-card-front']//div[@class='col-idc full-info dental-bottom']");
	public static final By dental_Website=By.xpath("(//div[@class='panel dyk-panel']//div[@class='id-card id-card-back-dental']//strong)[1]");
	public static final By dental_TagLine=By.xpath("//div[@class='panel dyk-panel']//div[@class='id-card id-card-back-dental']//p[3]");
	public static final By dental_InsTextMembers=By.xpath("(//div[@class='panel dyk-panel']//div[@class='id-card id-card-back-dental']//p)[1]");
	public static final By dental_InsTextProviders=By.xpath("(//div[@class='panel dyk-panel']//div[@class='id-card id-card-back-dental']//p)[2]");
	public static final By dental_CustNo=By.xpath("//div[@class='panel dyk-panel']//div[@class='id-card id-card-back-dental']//p[contains(text(),'Customer Service: ')]//following-sibling::strong");
	
	//div[@class='panel dyk-panel']//div[@class='id-card id-card-front']
	/*EVBI Objects*/
	public static final By welcomeevbi = By.xpath("//h2[contains(text(),'View Eligibility & Benefits')]");
	public static final By membreno =By.id("MemNo");
	public static final By searchbutton =By.xpath("//input[@value='Search']");
	public static final By firstlink =By.xpath("(//td/font[contains(text(),'Active Contracts for Search Date')]/following::td/a)[1]");
	public static final By membername =By.xpath("//tr/td[contains(text(),'Policy Holder')]/following-sibling::td[1]");
	public static final By policyholderid =By.xpath("//tr/td[contains(text(),'Policy Holder ID')]/following-sibling::td");
	public static final By groupno =By.xpath("//tr/td[contains(text(),'Group Number')]/following-sibling::td[1]");
	public static final By customerno =By.xpath("//tr/td[contains(text(),'Customer Service')]/following-sibling::td[1]");
	
}


