package commonComponents.com.cognizant.framework.selenium;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;

import com.google.common.base.Function;

import commonComponents.com.cognizant.framework.Status;
import commonComponents.supportlibraries.DriverScript;
import commonComponents.supportlibraries.ReusableLibrary;
import commonComponents.supportlibraries.ScriptHelper;

public class UtilityFunctions extends ReusableLibrary{
	
	/**
	 * Constructor to initialize the component library
	 * @param scriptHelper The {@link ScriptHelper} object passed from the {@link DriverScript}
	 */
	public UtilityFunctions(ScriptHelper scriptHelper) {
		super(scriptHelper);
	}	
	
	private static Connection con=null;
	private static Statement stmt=null;	
	private static ResultSet rs=null;

	public void highlightWebElement(WebElement targetElement){
		JavascriptExecutor js=(JavascriptExecutor)(driver);
		js.executeScript("arguments[0].setAttribute('style',arguments[1]);",targetElement,"color: Red;border: 2px Solid Red");
		driverUtil.waitFor(200);
		js.executeScript("arguments[0].setAttribute('style',arguments[1]);",targetElement,"");		
	}
	
	public String getDate(String format){
		Date dt=new Date();
		SimpleDateFormat datFormat=new SimpleDateFormat(format);
		return datFormat.format(dt).toString();
	}
	
	public String getPastOrFutureDate(String format,String pastOrFuture){
		Calendar cal=Calendar.getInstance();
		if(pastOrFuture.equals("Past")){
			cal.add(Calendar.DATE, -1);
		}else if(pastOrFuture.equals("Future")){
			cal.add(Calendar.DATE, +1);
		}
		Date expDate=cal.getTime();
		SimpleDateFormat datFormat=new SimpleDateFormat(format);
		return datFormat.format(expDate).toString();
	}
	
	public String getFirstSelectedOptionText(By by){
		Select dropDownList = new Select(driver.findElement(by));
		return dropDownList.getFirstSelectedOption().getText().trim();
	}
	
	public void selectValueFromDropdownForGivenText(By by,String textToBeSelected){
		Select dropDownList = new Select(driver.findElement(by));
		boolean flag=false;
		List<WebElement> options = dropDownList.getOptions();
		for(WebElement option:options){
			if((option.getText().trim()).equals(textToBeSelected)){
				dropDownList.selectByVisibleText(textToBeSelected);
				flag=true;
				break;
			}
		}
		if(flag){
			report.updateTestLog("select Value From Dropdown For Given Text", "'"+textToBeSelected+"' is selected", Status.PASS);
		}else{
			report.updateTestLog("select Value From Dropdown For Given Text", "'"+textToBeSelected+"' is not selected", Status.FAIL);
		}
	}
	
	public void selectValueFromDropdownForGivenId(By by,int id){
		Select dropDownList = new Select(driver.findElement(by));
		boolean flag=false;
		List<WebElement> options = dropDownList.getOptions();			
			if(id<=options.size()){
				dropDownList.selectByIndex(id);
				flag=true;				
			}
		if(flag){
			report.updateTestLog("select Value From Dropdown For Given id", "value in index '"+id+"' is selected", Status.PASS);
		}else{
			report.updateTestLog("select Value From Dropdown For Given id", "value in index '"+id+"' is not selected", Status.FAIL);
		}
	}

	public void verifyTextAvailableInDropdown(By element,String expectedText){
		//String[] expText=expectedText.split(";");		
		Select dropDownList = new Select(driver.findElement(element));
		List<WebElement> options = dropDownList.getOptions();
		//String[] actText=new String[options.size()];
		String actText="";
		for(int i=0;i<options.size();i++){
			//actText[i]=options.get(i).getText();
			actText=actText+";"+options.get(i).getText();
		}
		actText=actText.substring(1, actText.length());
		//if(Arrays.deepEquals(actText, expText)){
		if(actText.contains(expectedText)){
			report.updateTestLog("Available Text values in dropdown", "'"+expectedText+"' values should be available", Status.PASS);
		}else{
			report.updateTestLog("Available Text values in dropdown", "'"+expectedText+"' values should be available", Status.FAIL);
		}
	}
	
	public void performAction(By element,String actionToBePerformed,String text){
		performAction(element, actionToBePerformed, text, 20);
	}
	
	public void performAction(By element,String actionToBePerformed,String text, int timeout){
		actionToBePerformed=actionToBePerformed.toUpperCase();
		if(driver.isElementVisible(element, timeout) && isElementEnabled(element)){  			
			switch(actionToBePerformed){
				case "SENDKEYS":						
					driver.findElement(element).clear();
					if(!text.equals("")){
						driver.findElement(element).sendKeys(text);					
						report.updateTestLog("Data entry","Text "+text+" is entered in the field "+element.toString() ,Status.DONE);
					}
					break; //
				case "CLICK":			
					driver.findElement(element).click();
					report.updateTestLog("Element click","Element "+element.toString()+" is clicked" ,Status.DONE);					
					break;
				case "SCROLLANDCLICK":
					driver.scrollToTopAndClick(driver.findElement(element));
					report.updateTestLog("Scroll element and click","Element "+element.toString()+" is scrolled to top and clicked" ,Status.DONE);					
					break;
				case "MOVEANDCLICK":
					driver.moveToElementAndClick(driver.findElement(element));	
					report.updateTestLog("Move to element and click","Moved to "+element.toString()+" element and clicked" ,Status.DONE);					
					break;
				case "SCROLLCLICKANDSENDKEYS":
					driver.moveToElementAndClick(driver.findElement(element));	
					report.updateTestLog("Move to element and click","Moved to "+element.toString()+" element and clicked" ,Status.DONE);
					driver.findElement(element).clear();
					if(!text.equals("")){
						driver.findElement(element).sendKeys(text);					
						report.updateTestLog("Data entry","Text "+text+" is entered in the field "+element.toString() ,Status.DONE);
					}
					break;
				case "SCROLLDOWNANDCLICK":
					driverUtil.waitFor(3000);
					performAction(element,"SCROLLDOWN","");
					performAction(element,"CLICK","");
                    report.updateTestLog("Scroll element and click","Element "+element.toString()+" is scrolled to down and clicked" ,Status.DONE);                    
                    break;
			}				
		}else{
			report.updateTestLog("Element Visible and enabled", "Element "+element.toString()+" is not Visible or not enabled", Status.FAIL);
		}
	}
	
	public void performAction(WebElement element,String actionToBePerformed,String elementDesc,String text){
		performAction(element, actionToBePerformed,elementDesc, text, 20);
	}
	
	public void performAction(WebElement element,String actionToBePerformed,String text, String elementDesc, int timeout){
		actionToBePerformed=actionToBePerformed.toUpperCase();
		if(element.isDisplayed() && element.isEnabled()){  			
			switch(actionToBePerformed){
				case "SENDKEYS":						
					element.clear();
					if(!text.equals("")){
						element.sendKeys(text);					
						report.updateTestLog("Data entry","Text "+text+" is entered in the field "+element.toString() ,Status.DONE);
					}
					break;
				case "CLICK":			
					element.click();
					report.updateTestLog("Element click","Element "+elementDesc+" is clicked" ,Status.DONE);					
					break;
				case "SCROLLANDCLICK":
					driver.scrollToTopAndClick(element);
					report.updateTestLog("Scroll element and click","Element "+elementDesc+" is scrolled to top and clicked" ,Status.DONE);					
					break;
				case "MOVEANDCLICK":
					driver.moveToElementAndClick(element);	
					report.updateTestLog("Move to element and click","Moved to "+elementDesc+" element and clicked" ,Status.DONE);					
					break;
			}				
		}else{
			report.updateTestLog("Element Visible and enabled", "Element "+elementDesc+" is not Visible or not enabled", Status.FAIL);
		}
	}

	public void validateElementContents(){
		validateElementContents(null);
	}
	
	public void validateElementContents(WebElement parentElement)
	{
		String[] labelsCollection = dataTable.getData("Controls_Data", "LabelContents").split(";");
		String[] labelTagsCollection = dataTable.getData("Controls_Data", "LabelTagNames").split(";");
		String[] labelsDisplay = dataTable.getData("Controls_Data", "LabelsDisplayType").split(";");

		for(int index=0; index < labelsCollection.length; index++)
		{
			String eachLabelName = labelsCollection[index];
			String eachTagName = readStringArrayValue(labelTagsCollection, index);
			String eachDisplayType = readStringArrayValue(labelsDisplay, index);
			String xpathExpression = ".//" + eachTagName + "[.='" + eachLabelName + "']";
			if(eachDisplayType.equalsIgnoreCase("RegExp")){
				xpathExpression = ".//" + eachTagName + "[contains(., '" + eachLabelName + "')]";
			}
			
			isElementDisplayed(By.xpath(xpathExpression), eachLabelName + " Label", parentElement);
		}
	}
			
	public void fillForm()
	{
		String[] labelsCollection = dataTable.getData("Fill_Data", "LabelContents").split(";");
		String[] labelTagsCollection = dataTable.getData("Fill_Data", "LabelTagNames").split(";");
		String[] labelsDisplay = dataTable.getData("Fill_Data", "LabelsDisplayType").split(";");
		String[] inputData = dataTable.getData("Fill_Data", "DataToBeFilled").split(";");

		for(int index=0; index < labelsCollection.length; index++)
		{
			String eachLabelName = labelsCollection[index];
			String eachTagName = readStringArrayValue(labelTagsCollection, index);
			String eachDisplayType = readStringArrayValue(labelsDisplay, index);
			String data=readStringArrayValue(inputData, index);
			String xpathExpression = ".//" + eachTagName + "[.='" + eachLabelName + "']";
			if(eachDisplayType.equalsIgnoreCase("RegExp")){
				xpathExpression = ".//" + eachTagName + "[contains(., '" + eachLabelName + "')]";
			}
			
			//xpathExpression=xpathExpression+"/following-sibling::input";
			xpathExpression=xpathExpression+"/..//input";
			driver.findElement(By.xpath(xpathExpression)).sendKeys(data);			
		}
	}
	
	public String fetchFilledData(String expLabelName){
		String[] labelsCollection = dataTable.getData("Fill_Data", "LabelContents").split(";");
		String[] labelTagsCollection = dataTable.getData("Fill_Data", "LabelTagNames").split(";");
		String[] labelsDisplay = dataTable.getData("Fill_Data", "LabelsDisplayType").split(";");
		String result=""; 
		
		for(int index=0; index < labelsCollection.length; index++)
		{
			String eachLabelName = labelsCollection[index];
			if(eachLabelName.equals(expLabelName)){
				String eachTagName = readStringArrayValue(labelTagsCollection, index);
				String eachDisplayType = readStringArrayValue(labelsDisplay, index);
				
				String xpathExpression = ".//" + eachTagName + "[.='" + eachLabelName + "']";
				if(eachDisplayType.equalsIgnoreCase("RegExp")){
					xpathExpression = ".//" + eachTagName + "[contains(., '" + eachLabelName + "')]";
				}
				
				//xpathExpression=xpathExpression+"/following-sibling::input";
				xpathExpression=xpathExpression+"/..//input";
				result=driver.findElement(By.xpath(xpathExpression)).getAttribute("value");
				break;
			}
		}
		return result;
	}
	
	public void linkNavigation(WebElement parentElement)
	{
		String linkName = dataTable.getData("Links_Data", "LinkName");
		String linkTagName = dataTable.getData("Links_Data", "LinkTagName");
		String linkPageTitle = dataTable.getData("Links_Data", "LinkNavPageTitle");
		String navigatedElementCss = dataTable.getData("Links_Data", "LinkNavVerifyElementCss");
		String navigatedElementXpath = dataTable.getData("Links_Data", "LinkNavVerifyElementXpath");
		String linkNavUrl = dataTable.getData("Links_Data", "LinkNavUrl");
		String linkNavType = dataTable.getData("Links_Data", "LinkNavType");

		if(!linkName.isEmpty())
		{
			String linkXPath="";
			if(linkNavType.equalsIgnoreCase("RegExp")){
				linkXPath = ".//a[contains(., '" + linkName + "')] | .//*[contains(., '" + linkName + "')]/parent::a";
			}else{
				linkXPath = ".//a[.='" + linkName + "'] | .//*[.='" + linkName + "']/parent::a";
			}
			
			if(!linkTagName.isEmpty())
			{
				if(linkNavType.equalsIgnoreCase("RegExp")){
					linkXPath = ".//" + linkTagName + "[contains(., '" + linkName + "')]";
				}else{
					linkXPath = ".//" + linkTagName + "[.='" + linkName + "']";
				}				
			}
			
			if(isElementDisplayed(By.xpath(linkXPath), linkName + " Link", parentElement))
			{
				if(parentElement==null)
					driver.scrollToTopAndClick(driver.findElement(By.xpath(linkXPath)));
				else
					driver.scrollToTopAndClick(parentElement.findElement(By.xpath(linkXPath)));
				
				// Wait till page load
				driverUtil.waitFor(500);
				driver.waitTillPageLoaded();
				// Check Link Navigation
				if(!navigatedElementXpath.isEmpty())
				{
					isElementDisplayed(By.xpath(navigatedElementXpath), linkName + " Link Navigation", null);
				}
			}
		}
		

	}
		
	public boolean isElementDisplayed(By locator, String elementDesc, WebElement parentElement)
	{
		WebElement targetElement;
		boolean elementDisplayed = false;
		try {
			if(parentElement == null)
			{
				targetElement = driver.findElement(locator);
			}
			else
			{
				targetElement = parentElement.findElement(locator);
			}
			elementDisplayed = targetElement.isDisplayed();
		}
		catch (NoSuchElementException e) {
			
		}
		if(!elementDesc.isEmpty())
		{
			if(elementDisplayed)
			{
				/*report.updateTestLog("ElementDisplay", elementDesc + " should be displayed in the page",  Status.PASS);
			}
			else
			{
				report.updateTestLog("ElementDisplay", elementDesc + " should be displayed in the page",  Status.FAIL);**/
			}
		}
		return elementDisplayed;
	}
	
	public String readStringArrayValue(String[] arrayName, int index)
	{
		try {
			return arrayName[index];
		}
		catch (Exception e) {
			return "";
		}
	}
	
	public boolean isElementEnabled(By arg0) {
		boolean elementEnabled = false;				
		if(driver.findElement(arg0).isEnabled()){
			elementEnabled = true;
		}else{
			elementEnabled = false;
		}
		return elementEnabled;
	}
	
	public void verifyTextPresentInPage(String textValue){
		if(driver.getPageSource().contains(textValue)){  
			report.updateTestLog("Text availability", "Text '"+textValue+"' is available in page", Status.PASS);
		}else{
			report.updateTestLog("Text availability", "Text '"+textValue+"' is unavailable in page", Status.FAIL);
		}
	}	
	
	public void verifyTextPresentInHTMLBody(String textValue){
		String actualBodyText=driver.findElement(By.tagName("body")).getText();
		if(actualBodyText.contains(textValue)){  
			report.updateTestLog("Text availability", "Text '"+textValue+"' is available in page", Status.PASS);
		}else{
			report.updateTestLog("Text availability", "Text '"+textValue+"' is unavailable in page", Status.FAIL);
		}
	}
	
	public void verifyCurrentURL(String expectedURL){
		driverUtil.waitFor(500);
		String actualURL=driver.getCurrentUrl();
		if(actualURL.contains(expectedURL)){
			report.updateTestLog("current URL validation", "current url is '"+actualURL+"' as expected", Status.PASS);
		}else{
			report.updateTestLog("current URL validation", "current url is '"+actualURL+"' and expected is'"+expectedURL+"'", Status.FAIL);
		}
	}
	
	public boolean switchToFrame(By element){
		boolean frameSwitched;
		try{
			driver.switchTo().frame(driver.findElement(element));
			report.updateTestLog("switch to frame", "switched to frame "+element.toString(), Status.PASS);
			frameSwitched=true;
		}catch(NoSuchElementException e){
			report.updateTestLog("switch to frame", "switched to frame "+element.toString(), Status.FAIL);
			frameSwitched=false;
		}
		return frameSwitched;
	}
	
	public void switchToWindow(String expectedNewURL){ //switch to window with expected URL and report the same
		boolean windowSwitched=false;
		String actualNewURL="";
		String parentWindow=driver.getWindowHandle();
		Set<String> handles=driver.getWindowHandles();
		
		for(String windowHandle: handles){
			if(!windowHandle.equals(parentWindow)){
				driver.switchTo().window(windowHandle);
				driverUtil.waitFor(300);
				actualNewURL=driver.getCurrentUrl();	
				if(actualNewURL.equals(expectedNewURL)){
					windowSwitched=true;
					break;
				}
			}			
		}
		
		if(windowSwitched){
			report.updateTestLog("switch to window", "Should be switched to window with URL '"+expectedNewURL, Status.PASS);
		}else{
			report.updateTestLog("switch to window", "Should be switched to window with URL '"+expectedNewURL, Status.FAIL);	
		}
		
		driver.switchTo().window(parentWindow);
	}
	
	public String getTableHeader(By elementTable){
		List<WebElement> headersList=driver.findElement(elementTable).findElements(By.tagName("th"));
		String headers="";
		for(WebElement eachHeader:headersList){
			if(!eachHeader.getText().equals("")){
				headers=headers+";"+eachHeader.getText().trim();
			}						
		}
		headers=headers.substring(1, headers.length());
		return headers;
	}
	
	public String getTableHeader(WebElement elementTable){
		List<WebElement> headersList=elementTable.findElements(By.tagName("th"));
		String headers="";
		for(WebElement eachHeader:headersList){
			if(!eachHeader.getText().equals("")){
				headers=headers+";"+eachHeader.getText().trim();
			}						
		}
		headers=headers.substring(1, headers.length());
		return headers;
	}
	
	public String getTabTitles(By element){
		List<WebElement> tabList=driver.findElements(element);
		String tabTitles="";
		for(WebElement eachTab:tabList){
			tabTitles=tabTitles+";"+eachTab.getText().trim();			
		}
		tabTitles=tabTitles.substring(1, tabTitles.length());
		return tabTitles;
	}
	
	public String getLinkNames(By element){
		List<WebElement> lnkList=driver.findElements(element);
		String lnkNames="";
		for(WebElement eachlink:lnkList){
			lnkNames=lnkNames+";"+eachlink.getText().trim();			
		}
		lnkNames=lnkNames.substring(1, lnkNames.length());
		lnkNames=lnkNames.replace("\n", " ");
		return lnkNames;
	}
	
	public String getWebTableCellData(By elementTable,int row,int col,String tableDesc){
		return getWebTableCellData(elementTable, row, col, tableDesc, true);
	}
	
	public String getWebTableCellData(By elementTable,int row,int col,String tableDesc, boolean includeHeaderSection){
		String innertext="";
		try{
			WebElement table=driver.findElement(elementTable);
			try{
				String xpathValue = ".//tr["+row+"]/td["+col+"]";
				if(!includeHeaderSection)
				{
					xpathValue = ".//tbody/tr["+row+"]/td["+col+"]";
				}
				innertext=table.findElement(By.xpath(xpathValue)).getText();
			}catch(NoSuchElementException e){
				report.updateTestLog("Display of expected cell in table", tableDesc+" table don't have row("+row+") column("+col+")", Status.FAIL);
			}
		}catch(NoSuchElementException e){
			report.updateTestLog("Display of table", tableDesc+" table is not found", Status.FAIL);
		}
		return innertext;
	}
	
	public String getWebTableCellData(WebElement elementRow,int col,String tableDesc){
		String innertext="";
			try{
				innertext=elementRow.findElement(By.xpath(".//td["+col+"]")).getText();
			}catch(NoSuchElementException e){
				report.updateTestLog("Display of expected cell in table", tableDesc+" table don't have column("+col+")", Status.FAIL);
			}
		return innertext;
	}
	
	public WebElement getWebTableCellItem(By elementTable,int row,int col,By targetElementInTable,String tableDesc){
		return getWebTableCellItem(elementTable, row, col, targetElementInTable, tableDesc, true);
	}
	
	public WebElement getWebTableCellItem(By elementTable,int row,int col,By targetElementInTable,String tableDesc, boolean includeHeaderRow){
		WebElement targetElement=null;
		try{
			WebElement table=driver.findElement(elementTable);
			try{
				String xpathValue = ".//tr["+row+"]/td["+col+"]";
				if(!includeHeaderRow)
				{
					xpathValue = ".//tbody/tr["+row+"]/td["+col+"]";
				}
				WebElement tableCell=findElementThroFluentWait(table,By.xpath(xpathValue),30);
				if(tableCell!=null){				
						targetElement=tableCell.findElement(targetElementInTable);				
				}
			}catch(NoSuchElementException e){
				report.updateTestLog("Display of expected cell in table", tableDesc+" table don't have row("+row+") column("+col+")", Status.FAIL);
			}
		}catch(NoSuchElementException e){
			report.updateTestLog("Display of table", tableDesc+" table is not found", Status.FAIL);
		}
		return targetElement;
	}
		
	public WebElement getWebTableCellItem(By elementTable,int row,By targetElementInTable,String tableDesc){
		WebElement targetElement=null;
		try{
			WebElement table=driver.findElement(elementTable);
			try{
				WebElement tableCell=findElementThroFluentWait(table,By.xpath(".//tr["+row+"]"),30);
				if(tableCell!=null){				
						targetElement=tableCell.findElement(targetElementInTable);				
				}
			}catch(NoSuchElementException e){
				report.updateTestLog("Display of expected cell in table", tableDesc+" table don't have row("+row+")", Status.FAIL);
			}
		}catch(NoSuchElementException e){
			report.updateTestLog("Display of table", tableDesc+" table is not found", Status.FAIL);
		}
		return targetElement;
	}
	
	public WebElement getWebTableCellItem(By elementTable,String cellContent,String tableDesc){
		WebElement targetElement=null;
		try{
			WebElement table=driver.findElement(elementTable);
			try{
				targetElement=table.findElement(By.xpath(".//tr//td[contains(text(),'"+cellContent+"')]"));		
			}catch(NoSuchElementException e){
				report.updateTestLog("Display of expected element in table", tableDesc+" table don't have element containing text "+cellContent, Status.FAIL);
			}
		}catch(NoSuchElementException e){
			report.updateTestLog("Display of table", tableDesc+" table is not found", Status.FAIL);
		}
		return targetElement;
	}
	
	public List<WebElement> getRowsWithTargetElement(By elementTable,By targetElementInTable){
		List<WebElement> allrows=driver.findElement(elementTable).findElements(By.tagName("tr"));
		List<WebElement> requiredRows=new ArrayList<WebElement>();
		for(int i=1;i<allrows.size();i++){
			WebElement currentrow=allrows.get(i);//each row
			try{
				if(currentrow.findElement(targetElementInTable).isDisplayed()){
					requiredRows.add(currentrow);
				}
			}catch(NoSuchElementException e){
				
			}
		}
		return requiredRows;
	}
	
	public WebElement fluentWait(WebElement elementParent,final By elementTarget,long timeOutInSeconds){
		
		Wait<WebElement> wait=new FluentWait<WebElement>(elementParent)
				.withTimeout(timeOutInSeconds,TimeUnit.SECONDS)
				.pollingEvery(500,TimeUnit.MILLISECONDS)
				.ignoring(NoSuchElementException.class);
		
		WebElement targetElementFound=wait.until(new Function<WebElement,WebElement>(){
			public WebElement apply(WebElement elementParent){
				return elementParent.findElement(elementTarget);
			}
		});
		
		return targetElementFound;
	}
		
	public WebElement findElementThroFluentWait(WebElement elementParent,By elementTarget,long timeOutInSeconds){
		WebElement targetElementFound=null;
		try{
			targetElementFound=fluentWait(elementParent,elementTarget,timeOutInSeconds);
		}catch(Exception e){			
				report.updateTestLog("Display of element", elementTarget+" is not available", Status.FAIL);
		}
		return targetElementFound;
	}
	
	/**
	 * validate Headers Present in table
	 * @param element
	 * @param expectedHeaders
	 * @param tableDesc
	 */
	public void validateHeadersPresent(By element, String expectedHeaders, String tableDesc){
		String actualHeaders=getTableHeader(element);
		if(actualHeaders.equalsIgnoreCase(expectedHeaders)){
			report.updateTestLog("Display of "+tableDesc+" headers", "'"+expectedHeaders+"' should be displayed", Status.PASS);
		}else{
			report.updateTestLog("Display of "+tableDesc+" headers", "'"+expectedHeaders+"' should be displayed", Status.FAIL);
		}
	}
	
	public void validateHeadersPresent(WebElement element, String expectedHeaders, String tableDesc){
		String actualHeaders=getTableHeader(element);
		if(actualHeaders.equalsIgnoreCase(expectedHeaders)){
			report.updateTestLog("Display of "+tableDesc+" headers", "'"+expectedHeaders+"' should be displayed", Status.PASS);
		}else{
			report.updateTestLog("Display of "+tableDesc+" headers", "'"+expectedHeaders+"' should be displayed", Status.FAIL);
		}
	}
	
	public String buildStringWithNchar(char c,int n){
		return StringUtils.repeat(c, n);
	}	
	
	/**
	 * invokes Application
	 */
	public void invokeApplication(){
			String ApplicationURL=dataTable.getData("General_Data", "ApplicationURL_Test");
			String PageTitle=dataTable.getData("General_Data", "PageTitle");		
			driver.get(ApplicationURL);
			//verifies with page title
			if(driver.getTitle().trim().equals(PageTitle)){
				report.updateTestLog("Invoke Application", "Invoke the application @" +
					ApplicationURL, Status.PASS);
			}else{
				report.updateTestLog("Invoke Application", "Invoke the application @" +
						ApplicationURL, Status.FAIL);
			}
		}
	
	/**
	 * validate Error Message Displayed
	 * @param errorMessageToBeAppendedInLog
	 * @param errorElement TODO
	 */
	public void validateErrorMessageDisplayed(String errorMessageToBeAppendedInLog, By errorElement){
		String expErrorMsg=dataTable.getData("General_Data", "ExpectedErrorMsg").replace("  ", " ");
		String actErrorMsg=driver.findElement(errorElement).getText().trim();
		if(actErrorMsg.equals(expErrorMsg)){
			report.updateTestLog("Display of error message for "+errorMessageToBeAppendedInLog, "Error message '"+expErrorMsg+"' should be displayed", Status.PASS);
		}else{
			report.updateTestLog("Display of error message for "+errorMessageToBeAppendedInLog, "Error message '"+expErrorMsg+"' should be displayed", Status.FAIL);			
		}
	}
	
	public void validateWarningMessageDisplayed(String warningMessageToBeAppendedInLog, WebElement WarningElement){
		String actualMsg=WarningElement.getText().trim();
		String expectedMsg=dataTable.getData("General_Data", "WarningMessage");		
		if(actualMsg.equalsIgnoreCase(expectedMsg)){
			report.updateTestLog("Display of warning message for "+warningMessageToBeAppendedInLog, "warning message '"+expectedMsg+"' should be displayed", Status.PASS);
		}else{
			report.updateTestLog("Display of warning message for "+warningMessageToBeAppendedInLog, "warning message '"+expectedMsg+"' should be displayed", Status.FAIL);			
		}
	}
	
	public void validateWarningMessageDisplayed(String warningMessageToBeAppendedInLog, By WarningElement){
		validateWarningMessageDisplayed(warningMessageToBeAppendedInLog, driver.findElement(WarningElement));
	}
	
	public boolean regExpValidation(String pattern,String contentToValidate){		
		if(contentToValidate.matches(pattern)){
			return true;
		}else{
			return false;
		}
	}

	public WebElement findVisibleElementFromCollection(By locator, String elementDesc)
	{
		WebElement targetElement = null;
		for(WebElement eachElement : driver.findElements(locator))
		{
			if(eachElement.isDisplayed())
			{
				if(!elementDesc.isEmpty())
				{
					report.updateTestLog("Element", elementDesc + " should be displayed", Status.PASS);
				}
				targetElement = eachElement;
				break;
			}
		}
		if(targetElement == null && !elementDesc.isEmpty())
		{
			report.updateTestLog("Element", elementDesc + " should be displayed", Status.FAIL);
		}
		return targetElement;
	}
	
	public WebElement findMatchingElementFromCollection(By locator, String innerText, String elementDesc)
	{
		WebElement targetElement = null;
		String actualText;
		for(WebElement eachElement : driver.findElements(locator))
		{
			actualText = eachElement.getText();
			if(actualText.isEmpty()){
				actualText =driver.getInnerText(eachElement);
			}
			if(!actualText.isEmpty() && actualText.trim().equals(innerText))
			{
				if(!elementDesc.isEmpty())
				{
					report.updateTestLog("Element", elementDesc + " '" + innerText + "' should be available", Status.PASS);
				}
				targetElement = eachElement;
				break;
			}
		}
		if(targetElement == null && !elementDesc.isEmpty())
		{
			report.updateTestLog("Element", elementDesc + " '" + innerText + "' should be available", Status.FAIL);
		}
		return targetElement;
	}
	
	public WebElement findPartialMatchingElementFromCollection(By locator, String innerText, String elementDesc)
	{
		WebElement targetElement = null;
		String actualText;
		for(WebElement eachElement : driver.findElements(locator))
		{
			actualText = eachElement.getText();
			if(!actualText.isEmpty() && actualText.trim().contains(innerText))
			{
				if(!elementDesc.isEmpty())
				{
					report.updateTestLog("Element", elementDesc + " '" + innerText + "' should be available", Status.PASS);
				}
				targetElement = eachElement;
				break;
			}
		}
		if(targetElement == null && !elementDesc.isEmpty())
		{
			report.updateTestLog("Element", elementDesc + " '" + innerText + "' should be available", Status.FAIL);
		}
		return targetElement;
	}
	
	public String parsePhoneNumber(String format,String phoneNumber){
		if(format.equalsIgnoreCase("US")){
			phoneNumber="("+phoneNumber.substring(0, 3)+") "+phoneNumber.substring(3,6)+"-"+phoneNumber.substring(6,10);
		}
		return phoneNumber;
	}
	
	public void openDBConnection(String dbURL,String uName,String pswd){
		try {
			//load oracle jdbc driver
			Class.forName("oracle.jdbc.driver.OracleDriver");
			//create connection to db
			con=DriverManager.getConnection(dbURL, uName, pswd);
			//create statement object
			stmt=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
		} catch (Exception e) {
			report.updateTestLog("Error in DB connection",e.getMessage()+" "+e.getClass(), Status.FAIL);
			try {
				//close connection
				con.close();
			} catch (Exception e1) {
				report.updateTestLog("Error closing connection to DB",e1.getMessage()+" "+e1.getClass(), Status.FAIL);
			}			
		}		
	}
		
	public ResultSet getRecordSet(String query){
		try{
			//execute the sql query n store results in resultset
			rs=stmt.executeQuery(query);			
		} catch (Exception e) {
			report.updateTestLog("Error in DB query",e.getMessage()+" "+e.getClass(), Status.FAIL);
			try {
				//close connection
				con.close();
			} catch (Exception e1) {
				report.updateTestLog("Error closing connection to DB",e1.getMessage()+" "+e1.getClass(), Status.FAIL);
			}			
		}			
		return rs;
	}

	public void closeDBConnection(){
		try {
			//close connection
			con.close();
		} catch (Exception e1) {
			report.updateTestLog("Error closing connection to DB",e1.getMessage(), Status.FAIL);
		}
	}
	
	/**
	 * Description    :   Function to Connect FacetsDB
	 * Return Value   :   Connection
	 * Created By     :   Gandhimathi
	 * Created Date   :   11/27/2017 
	 * @return
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public Connection connectToFacetsDB() throws SQLException, ClassNotFoundException{
		// Create a variable for the connection string.   63.145.102.62,11001
		String DBServer = dataTable.getData("General_Data","DBServer");
		String DBName = dataTable.getData("General_Data","DBName");
		String DBUsername = dataTable.getData("General_Data","DBUsername");
		String DBPassword = dataTable.getData("General_Data","DBPassword");
		String connectionUrl = "jdbc:sqlserver://"+DBServer+";databaseName=" + DBName+";user="+DBUsername+";password="+DBPassword;
		// Declare the JDBC objects.  
		Connection con = null;  
		try {  
			// Establish the connection.  
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
			con = DriverManager.getConnection(connectionUrl); 
			}  
		
		catch (ClassNotFoundException e) {  
			throw e;  
		}  
		return con;
	}
	
	// Create and execute an SQL statement that returns some data. 
	public ResultSet executeQuery(String sql) throws SQLException, ClassNotFoundException{
		Statement stmt = null;  
		ResultSet rs = null;  
		Connection con = null;
		try{
			con = connectToFacetsDB(); 
			stmt = con.createStatement();  
			rs = stmt.executeQuery(sql);  
		}  
		catch (SQLException e) {  
			throw e;  
		} 
		return rs;
	}
	
	public WebElement getWebTableCellItem1(By elementTable,int row,By targetElementInTable,String tableDesc, boolean includeHeaderRow){
	    WebElement targetElement=null;
	    try{
	        WebElement table=driver.findElement(elementTable);
	        try{
	             String xpathValue = "/td["+row+"]";
	             if(!includeHeaderRow)
	             {
	                  xpathValue = "/td["+row+"]";
	             }
	             WebElement tableCell=findElementThroFluentWait(table,By.xpath(xpathValue),30);
	             if(tableCell!=null){                  
	                       targetElement=tableCell.findElement(targetElementInTable);                  
	             }
	        }catch(NoSuchElementException e){
	             report.updateTestLog("Display of expected cell in table", tableDesc+" table don't have row("+row+") ", Status.FAIL);
	        }
	    }catch(NoSuchElementException e){
	        report.updateTestLog("Display of table", tableDesc+" table is not found", Status.FAIL);
	    }
	    return targetElement;
	    
	}
	public WebElement WebTableCellData(By elementTable,int row,int col,String tableDesc){
        WebElement innertext=null;
        try{
            WebElement table=driver.findElement(elementTable);
            try{
                 innertext=table.findElement(By.xpath(".//tr["+row+"]/td["+col+"]"));;
                 
            }catch(NoSuchElementException e){
                 report.updateTestLog("Display of expected cell in table", tableDesc+" table don't have row("+row+") column("+col+")", Status.FAIL);
            }
        }catch(NoSuchElementException e){
            report.updateTestLog("Display of table", tableDesc+" table is not found", Status.FAIL);
        }
        return innertext;
   }
	public void openFacetsDBConnection(String connectionUrl){
	    
	    try {
	        //load oracle jdbc driver
	        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
	        //create connection to db
	        con=DriverManager.getConnection(connectionUrl);
	        //create statement object
	         stmt=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
	    } catch (Exception e) {
	        report.updateTestLog("Error in DB connection",e.getMessage()+" "+e.getClass(), Status.FAIL);
	        try {
	             //close connection
	             con.close();
	        } catch (Exception e1) {
	             report.updateTestLog("Error closing connection to DB",e1.getMessage()+" "+e1.getClass(), Status.FAIL);
	        }             
	    }  
	    
	}
	public String getPastOrFutureDate(String format,String pastOrFuture,int numberofdays){
        Calendar cal=Calendar.getInstance();
        if(pastOrFuture.equals("Past")){
           cal.add(Calendar.DATE, -numberofdays);
            
        }else if(pastOrFuture.equals("Future")){
            cal.add(Calendar.DAY_OF_YEAR, +numberofdays);
        }
        Date expDate=cal.getTime();
        SimpleDateFormat datFormat=new SimpleDateFormat(format);
        return datFormat.format(expDate).toString();
   }

	public String getTextFromElement(By element)
    {
    	
                    if((driver.findElement(element)).isDisplayed())
                    {
                                    return driver.findElement(element).getText();
                    }
                    else
                    {
                                    return "Specified Object Not Found in Page";
                    }
    } 
	

}
